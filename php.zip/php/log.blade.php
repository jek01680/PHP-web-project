<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : Wide-Range
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20140315

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="UTF-8" />
    <title></title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
    <!--[if IE 6]>
    <link href="default_ie6.css" rel="stylesheet" type="text/css" />
    <![endif]-->
</head>
<body>
<div id="wrapper">
    <div id="header-wrapper">
        <! 제목>
        <head>
            <meta charset="utf-8" />
            <title>CSS</title>
            <style>
                #header {
                    width: 1000px;
                    margin: 0px auto;
                }

                #logo {
                    font-family: Calibri;
                    font-style: italic;
                    font-weight: lighter;
                    margin-top: 300px;
                    margin-left: 250px;
                    width: 500px;
                }
            </style>
        </head>
        <div id="header" class="container">
            <div id="logo">
                <h1><a href="#">'4' to 世明 </a></h1>
                <p>by.computer science</p>
            </div>
        </div>
        <!상단메뉴>
        <style>
            #menu {
                width: 1000px;
                text-align: center;
            }
        </style>
        <div id="menu" class="container">
            <ul>

                <li class="current_page_item"><a href="intro.html" target="_blank" accesskey="1" title="">home</a></li>
                <li><a href="dorcount.html" target="_blank" accesskey="2" title="">Dormitory</a></li>
                <li><a href="lecevalu.html" target="_blank" accesskey="3" title="">Lecture</a></li>
                <li><a href="delivery.html" target="_blank" accesskey="4" title="">Delivery</a></li>
                <li><a href="http://its.okjc.net/m01/map?category=1" target="_blank" accesskey="5" title="">31'Bus</a></li>
                <li><a href="log.html" target="_blank" accesskey="6" title="">Log In/Join us</a></li>

            </ul>
        </div>
    </div>
</div>
</body>
<!페이지 section>
<head>
    <meta charset="utf-8" />
    <title>CSS</title>
    <style>
        #jb-container {
            width: 1160px;
            margin: 0px auto;
            padding: 20px;
            border: 1px solid #bcbcbc;
        }

        #jb-content {
            width: 500px;
            padding: 20px;
            margin: auto;
            margin-bottom: 20px;
            align-content:center;
            border: 1px solid #bcbcbc;
        }
        #jb-footer {
            clear: both;
            padding: 5px;
            border: 1px solid #bcbcbc;
        }
        .form-style-w3ls input[type="text"], .form-style-w3ls input[type="email"], .form-style-w3ls input[type="password"], select {
            outline: none;
            font-size: 14px;
            border: none;
            color: #666;
            background: #f1f1f1;
            letter-spacing: 0.5px;
            padding: 14px 20px;
            width: 100%;
            box-sizing: border-box;
            margin-bottom: 15px;
        }

        .form-style-w3ls button.btn {
            color: #fff;
            background: #3369e7;
            border: none;
            padding: 14px 0;
            outline: none;
            border-radius: 0;
            width: 100%;
            font-size: 15px;
            cursor: pointer;
            letter-spacing: 1px;
            -webkit-transition: 0.5s all;
            -o-transition: 0.5s all;
            -moz-transition: 0.5s all;
            -ms-transition: 0.5s all;
            transition: 0.5s all;
        }

        .form-style-w3ls input[type="submit"]:hover {
            background: #dc3545;
        }

        .padding {
            padding: 2.5em;
            background: #fff;
        }

        .form-style-w3ls span {
            font-size: 13px;
            color: #666;
        }

        .form-style-w3ls span a {
            color: #3369e7;
        }

    </style>
</head>
<body>
<div id="jb-container">
    <div id="jb-content">
        <div class="padding">
            <form action="#" method="post">
                <h5 class="mb-3">회원가입 후 사용해 주시기 바랍니다.</h5>
                <div class="form-style-w3ls">
                    <input placeholder="이메일 주소(ex. ******@*****)" name="email" type="email"  />
                    <input placeholder="비밀번호" name="number" type="password" />
                    <button Class="btn" style="border:1px solid; margin-bottom:5px;"> Get Started</button>
                    <button Class="btn" value="버튼" onclick="window.open('join.html')" style="border:1px solid;"> Join Us</button>
                </div>
            </form>
        </div>
    </div>

    <div id="jb-footer">
        <p>기숙사와 강의는 로그인 후 사용가능하며 '</p>
    </div>
</div>

<div id="portfolio-wrapper">
    <div id="portfolio" class="container">
        <div class="title">
            <h2>세명대학교 컴퓨터학부 캡스톤 디자인 수업</h2>
            <span class="byline">Ich habe alles alleine gemacht.</span>
        </div>
        <div class="column1">
            <div class="box">
                <h3>Leader/Design</h3>
                <p>ㅈㅅㅎ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column2">
            <div class="box">
                <h3>Design</h3>
                <p>ㅅㅇㅅ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column3">
            <div class="box">
                <h3>Data Base</h3>
                <p>ㅊㅁㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column4">
            <div class="box">
                <h3>Main</h3>
                <p>ㅈㅇㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>