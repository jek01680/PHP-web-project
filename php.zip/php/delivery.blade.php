<!doctype html>
<html lang="ko">
<!페이지 제목>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="UTF-8" />
    <title></title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
    <script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
</head>
<body>
<div id="wrapper">
    <div id="header-wrapper">
        <head>
            <meta charset="utf-8" />
            <title>CSS</title>
            <style>
                #header {
                    width: 1000px;
                    margin: 0px auto;
                }

                #logo {
                    font-family: Calibri;
                    font-style: italic;
                    font-weight: lighter;
                    margin-top: 300px;
                    margin-left: 250px;
                    width: 500px;
                }
            </style>

        </head>
        <div id="header" class="container">
            <div id="logo">
                <h1><a href="#">'4' to 世明 </a></h1>
                <p>by.computer science</p>
            </div>
        </div>
        <style>
            #menu {
                width: 1000px;
                text-align: center;
            }
        </style>
        <div id="menu" class="container">
            <ul>

                <li class="current_page_item"><a href="intro.html" target="_blank" accesskey="1" title="">home</a></li>
                <li><a href="dorcount.html" target="_blank" accesskey="2" title="">Dormitory</a></li>
                <li><a href="lecevalu.html" target="_blank" accesskey="3" title="">Lecture</a></li>
                <li><a href="delivery.html" target="_blank" accesskey="4" title="">Delivery</a></li>
                <li><a href="http://its.okjc.net/m01/map?category=1" target="_blank" accesskey="5" title="">31'Bus</a></li>
                <li><a href="log.html" target="_blank" accesskey="6" title="">Log In/Join us</a></li>

            </ul>
        </div>
    </div>
</div>
</body>

<!페이지 section>
<head>
    <meta charset="utf-8" />
    <title>CSS</title>
    <style>
        #jb-container {
            width: 1160px;
            margin: 0px auto;
            padding: 20px;
            border: 1px solid #bcbcbc;
        }
        #jb-content {
            width: 860px;
            padding: 20px;
            margin-bottom: 20px;
            float: right;
            border: 1px solid #bcbcbc;
        }
        #jb-sidebar {
            width: 200px;
            padding: 20px;
            margin-bottom: 20px;
            float: left;

        }
        #jb-footer {
            clear: both;
            padding: 20px;
            border: 1px solid #bcbcbc;
        }
    </style>
</head>
<body>
<div id="jb-container">
    <div id="jb-content">
        <h2> 배달 모음집</h2>
        <!검색창>
        <style>
            form {
                position: relative;
                width: 300px;
                margin: 15px auto;
            }
            .serch {
                background: #2f9daa;
            }

            .serch:after {
                content: "";
                clear: both;
                display: table
            }

            .serch form {
                width: auto;
                float: right;
                margin-right: 30px;
            }

            .serch input {
                width: 250px;
                height: 42px;
                padding-left: 15px;
                border-radius: 42px;
                border: 2px solid #324b4e;
                background: #F9F0DA;
                outline: none;
                position: relative;
                transition: .3s linear;
            }

            .serch input:focus {
                width: 300px;
            }

            .serch button {
                width: 42px;
                height: 42px;
                background: none;
                border: none;
                position: absolute;
                top: -2px;
                right: 0;
            }

            .serch button:before {
                content: "\f002";
                font-family: FontAwesome;
                color: #324b4e;
            }
        </style>
        <div class="serch">
            <form name=" input" action="getid.jsp" method="get">
                배달음식점 이름:
                <input type="text" placeholder="배달 음식점 이름 입력">
                <button type="submit" value="검색"></button>
            </form>
        </div>
        <!table생성>
        <style>
            .lectable table {
                width: 800px;
                margin: 20px 0;
                border: 0;
            }

            .lectable th {
                font-weight: bold;
                background-color: #c3b7c3;
                color: #000;
            }

            .lectable, .lectable th, .lectable td {
                font-size: 0.95em;
                text-align: center;
                padding: 4px;
                border-collapse: collapse;
            }

            .lectable th, .lectable td {
                border: 1px solid #ffffff;
                border-width: 1px 0 1px 0
            }

            .lectable tr {
                border: 1px solid #ffffff;
                margin: 0px;
                padding: 0px;
            }

            .lectable tr:nth-child(odd) {
                background-color: #f7f7f7;
            }

            .lectable tr:nth-child(even) {
                background-color: #ffffff;
            }

            .black_overlay {
                display: none;
                position: absolute;
                top: 0%;
                left: 0%;
                width: 100%;
                height: 100%;
                background-color: black;
                z-index: 1001;
                opacity: .80;
                filter: alpha(opacity=80);
            }

            .white_content {
                display: none;
                position: absolute;
                top: 25%;
                left: 25%;
                width: 700px;
                height: 800px;
                padding: 16px;
                border: 1px solid orange;
                background-color: white;
                z-index: 1002;
                overflow: auto;
            }

        </style>
        <table class="lectable">
            <tr>
                <th width="5%">번호</th>
                <th width="25%">음식점 이름</th>
                <th width="30">전화번호</th>
                <th width="10%">위치</th>
                <th width="20%">메뉴 바로가기</th>
            </tr>
            <tr>
                <td>1</td>
                <td>일미리 금계찜닭</td>
                <td>043-649-9995</td>
                <td>후문</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light1').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light1" class="white_content">
                        <img src="deliveryphoto/ilmiri.jpg"/>
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light1').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>
                    <div id="fade" class="black_overlay"></div>
                </td>

            </tr>

            <tr>
                <td>2</td>
                <td>웅이네 오돌뼈</td>
                <td>043-643-0101</td>
                <td>?</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light2').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light2" class="white_content">
                        <img src="deliveryphoto/wongs.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light2').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>
                    <div id="fade" class="black_overlay"></div>
                </td>
            </tr>
            <tr>
                <td>SAMPLE</td>
                <td>SAMPLE</td>
                <td>SAMPLE</td>
            </tr>
        </table>
        <div class="pagination">
            <center>
                <a href="#">&laquo;</a>
                <a href="#" class="active">1</a>
                <a href="#">2</a>
                <a href="#">3</a>
                <a href="#">4</a>
                <a href="#">5</a>
                <a href="#">6</a>
            </center>
        </div>

    </div>
    <!수직메뉴바생성>
    <style>
        body {
            margin: 20px auto;
            padding: 0;
            font-family: "맑은 고딕";
            font-size: 0.9em;
        }

        ul#navi {
            width: 200px;
            text-indent: 10px;
        }

        ul#navi, ul#navi ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }

        li.group {
            margin-bottom: 3px;
        }

        li.group div.title {
            height: 35px;
            line-height: 35px;
            background: #f1e020;
            cursor: pointer;
        }

        ul.sub li {
            margin-bottom: 2px;
            height: 35px;
            line-height: 35px;
            background: #f4f4f4;
            cursor: pointer;
        }

        ul.sub li a {
            display: block;
            width: 100%;
            height: 100%;
            text-decoration: none;
            color: #000;
        }

        ul.sub li:hover {
            background: #cf0;
        }
    </style>
    <div id="jb-sidebar">
        <ul id="navi">
            <li class="group">
                <div class="title">배달음식</div>
                <ul class="sub">
                    <li><a href="delivery.html">배달음식 모음</a></li>
                </ul>
            </li>
        </ul>
    </div>

    <div id="jb-footer">
        <p>Copyright</p>
    </div>
</div>

<div id="portfolio-wrapper">
    <div id="portfolio" class="container">
        <div class="title">
            <h2>세명대학교 컴퓨터학부 캡스톤 디자인 수업</h2>
            <span class="byline">Ich habe alles alleine gemacht.</span>
        </div>
        <div class="column1">
            <div class="box">
                <h3>Leader/Design</h3>
                <p>ㅈㅅㅎ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column2">
            <div class="box">
                <h3>Design</h3>
                <p>ㅅㅇㅅ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column3">
            <div class="box">
                <h3>Data Base</h3>
                <p>ㅊㅁㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column4">
            <div class="box">
                <h3>Main</h3>
                <p>ㅈㅇㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>