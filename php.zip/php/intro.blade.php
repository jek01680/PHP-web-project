<!doctype html>
<html lang="ko">
<!페이지 제목>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="UTF-8" />
    <title></title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet" href="css/intro.css">

    <!--[if IE 6]>
    <link href="default_ie6.css" rel="stylesheet" type="text/css" />
    <![endif]-->
</head>
<body>
<div id="wrapper">
    <div id="header-wrapper">
        <head>
            <meta charset="utf-8" />
            <title>CSS</title>
            <style>
                #header {
                    width: 1000px;
                    margin: 0px auto;
                }

                #logo {
                    font-family: Calibri;
                    font-style: italic;
                    font-weight: lighter;
                    margin-top: 300px;
                    margin-left: 250px;
                    width: 500px;
                }
            </style>

        </head>
        <div id="header" class="container">
            <div id="logo">
                <h1><a href="#">'4' to 世明 </a></h1>
                <p>by.computer science</p>
            </div>
        </div>
        <style>
            #menu{
                width:1000px;

                text-align:center;
            }
        </style>
        <div id="menu" class="container">
            <ul>

                <li class="current_page_item"><a href="intro.html" target="_blank" accesskey="1" title="">home</a></li>
                <li><a href="dorcount.html" target="_blank" accesskey="2" title="">Dormitory</a></li>
                <li><a href="lecevalu.html" target="_blank" accesskey="3" title="">Lecture</a></li>
                <li><a href="delivery.html" target="_blank" accesskey="4" title="">Delivery</a></li>
                <li><a href="http://its.okjc.net/m01/map?category=1" target="_blank" accesskey="5" title="">31'Bus</a></li>
                <li><a href="log.html" target="_blank" accesskey="6" title="">Log In/Join us</a></li>

            </ul>
        </div>
    </div>
</div>
</body>

<!페이지 section>
<head>
    <meta charset="utf-8" />
    <title>CSS</title>
    <style>
        #jb-container {
            width: 1160px;
            margin: 0px auto;
            padding: 30px;
            border: 1px solid #bcbcbc;
        }

        #jb-content {
            width: 510px;
            padding: 30px;
            margin-bottom: 30px;
            float: right;


        }

        #jb-sidebar {
            width: 510px;
            height: 500px;
            padding: 30px;
            margin-bottom: 30px;
            float: left;
            border-right: 1px dotted #000000;
        }

        #jb-footer {
            clear: both;
            padding: 5px;


        }
        #smhome {
            color: midnightblue;
            margin-left: 50px;
            margin-right: 60px;
            text-decoration: none;
            font-size: 1.2em;
        }
        #smpor {
            color: midnightblue;
            margin-right: 60px;
            text-decoration: none;
            font-size: 1.2em;
        }
        #smcom {
            color: midnightblue;
            font-size: 1.2em;
            text-decoration: none;
        }

    </style>
</head>
<body>
<div id="jb-container">
    <div id="jb-content">

        <h2>소개</h2>
        <p>
            2019년 1학기 컴퓨터학부 캡스톤 수업에서 '세명대 학우들의 편리도모'라는 주제를 가지고 밑의 4가지를 소주제로 하여 홈페이지를 만들었습니다.
            <br>▶기숙사 합|불 예측<br>▶강의평 쓰기<br>▶배달음식 모음집<br>▶31번 버스
        </p>
    </div>
    <div id="jb-sidebar">
        <img  style="margin:auto;" src="images/seraong.jpg" width="282" height="380" alt="" />
        <p style="font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif; margin-left:59px;">SMU mascot '세룡'</p>
    </div>

    <div id="jb-footer">
        <a id="smhome" href="http://www.semyung.ac.kr/kor.do">세명대학교 홈페이지 바로가기</a>
        <a id="smpor" href="http://setopia.semyung.ac.kr/main/index.jsp">세명대학교 포탈시스템 바로가기</a>
        <a id="smcom" href="http://www.semyung.ac.kr/scs.do">세명대학교 컴퓨터학부 과 홈페이지 바로가기</a>
    </div>
</div>


<div id="portfolio-wrapper">
    <div id="portfolio" class="container">
        <div class="title">
            <h2>세명대학교 컴퓨터학부 캡스톤 디자인 수업</h2>
            <span class="byline">Ich habe alles alleine gemacht.</span>
        </div>
        <div class="column1">
            <div class="box">
                <h3>Leader/Design</h3>
                <p>ㅈㅅㅎ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column2">
            <div class="box">
                <h3>Design</h3>
                <p>ㅅㅇㅅ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column3">
            <div class="box">
                <h3>Data Base</h3>
                <p>ㅊㅁㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column4">
            <div class="box">
                <h3>Main</h3>
                <p>ㅈㅇㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>