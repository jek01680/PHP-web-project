<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','mainpageController@index');
Route::get('/intro.html','introController@index');

Route::get('/dorcount.html','dorcountController@index');

Route::get('/lecevalu.html','lecevaluController@index');
Route::get('/lecwrite.html','lecwriteController@index');

Route::get('/delivery.html','deliveryController@index');

Route::get('/bus.html','busController@index');
Route::get('/log.html','logController@index');
Route::get('/join.html','joinController@index');

