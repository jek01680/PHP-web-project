<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class dorcountController extends Controller
{
    public function index()
    {
        return view ('dorcount') ;
    }
}