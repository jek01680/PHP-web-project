﻿<!doctype html>
<!페이지 제목>
<head>

    <meta name="viewport" content="width=device-width, initial-scale=0.5, minimum-scale=0.2, maximum-scale=0.3, user-scalable=yes" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="/css/default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="/css/fonts.css" rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>
<body>
    <div id="wrapper">
        <div id="header-wrapper">
                <style>
                    #header {
                        width: 1000px;
                        margin: 0px auto;
                    }

                    #logo {
                        font-family: Calibri;
                        font-style: italic;
                        font-weight: lighter;
                        margin-top: 300px;
                        margin-left: 250px;
                        width: 500px;
                    }
                    #menu {
                        width: 1000px;
                        text-align: center;
                        background-color: #1b6ef2;
                    }
                </style>

            <div id="header" class="container">
                <div id="logo">
                    <h1><a href="#">'4' to 世明 </a></h1>
                    <p>by.computer science</p>
                </div>
            </div>
            <div id="menu" class="container">
                <ul>
                    <li class="current_page_item"><a href="intro.html"  accesskey="1" title="">home</a></li>
                    <li><a href="dorcount.html"  accesskey="2" title="">Dormitory</a></li>
                    <li><a href="lecevalu.html"  accesskey="3" title="">Lecture</a></li>
                    <li><a href="delivery.html" accesskey="4" title="">Delivery</a></li>
                    <li><a href="http://its.okjc.net/m01/map?category=1"  accesskey="5" title="">31'Bus</a></li>
                    <li><a href="login"  accesskey="6" title="">Sign In</a></li>
                    <li><a href="register"  accesskey="7" title="">Sign Up</a></li>
                    <li><a href="login"  accesskey="8" title="">Log Out</a></li>
                </ul>
            </div>
        </div>
</body>

<!페이지 section>
    <style>
        #jb-container {
            width: 1160px;
            height: 610px;
            margin: 0px auto;
            padding: 30px;
            border: 1px solid #bcbcbc;
        }

        #jb-content {
            width: 1110px;
            height: 500px;
            padding: 30px;
            margin-bottom: 30px;
            margin: auto;
        }

        #jb-footer {
            clear: both;
            padding: 5px;
        }

        #title {
            text-align: center;
            font-size: 40px;
            font-family: Algerian;
            color: #091768;
            margin-bottom: 0px;
        }

        #subtitle {
            text-align: center;
            font-size: 20px;
            font-family: Bahnschrift;
            color: #111e65;
        }

        #smhome {
            color: midnightblue;
            margin-left: 50px;
            margin-right: 60px;
            text-decoration: none;
            font-size: 1.2em;
        }

        #smpor {
            color: midnightblue;
            margin-right: 60px;
            text-decoration: none;
            font-size: 1.2em;
        }

        #smcom {
            color: midnightblue;
            font-size: 1.2em;
            text-decoration: none;
        }
    </style>

<body>
    <div id="jb-container">
        <div id="jb-content">
            <p id="title">홈페이지 소개</p>
            <p id="subtitle">'세명대 학우들의 편리도모' 라는 주제를 가지고 컴퓨터학부 캡스톤 수업에서 만들었습니다. </p>        
                <style rel="stylesheet">
                    body {
                        background: -webkit-linear-gradient(45deg, rgba(66, 183, 245, 0.8) 0%, rgba(66, 245, 189, 0.4) 100%);
                        background: linear-gradient(45deg, rgba(66, 183, 245, 0.8) 0%, rgba(66, 245, 189, 0.4) 100%);
                    }
                    .wrap {
                        margin: 50px auto 0 auto;
                        width: 100%;
                        display: flex;
                        align-items: space-around;
                        max-width: 1200px;
                    }
                    .tile {
                        width: 380px;
                        height: 280px;
                        margin: 10px;
                        background-color: #99aeff;
                        display: inline-block;
                        background-size: cover;
                        position: relative;
                        cursor: pointer;
                        transition: all 0.4s ease-out;
                        box-shadow: 0px 35px 77px -17px rgba(0,0,0,0.44);
                        overflow: hidden;
                        color: white;
                        font-family: 'Roboto';
                    }

                        .tile img {
                            height: 100%;
                            width: 100%;
                            position: absolute;
                            top: 0;
                            left: 0;
                            z-index: 0;
                            transition: all 0.4s ease-out;
                        }

                        .tile .text {
                            /*   z-index:99; */
                            position: absolute;
                            padding: 30px;
                            height: calc(100% - 60px);
                            height: calc(100% - 60px);
                        }

                        .tile h1 {
                            font-weight: 300;
                            font-size:25px;
                            font-weight:500;
                            margin: 0;
                            text-shadow: 2px 2px 10px rgba(0,0,0,0.3);
                        }

                        .tile p {
                            font-weight: 300;
                            margin: 20px 0 0 0;
                            line-height: 25px;
                            /*   opacity:0; */
                            transform: translateX(-200px);
                            transition-delay: 0.2s;
                        }

                    .animate-text {
                        opacity: 0;
                        font-size:17px;
                        transition: all 0.6s ease-in-out;
                    }

                    .tile:hover {
                        /*   background-color:#99aeff; */
                        box-shadow: 0px 35px 77px -17px rgba(0,0,0,0.64);
                        transform: scale(1.05);
                    }

                        .tile:hover img {
                            opacity: 0.2;
                        }

                        .tile:hover .animate-text {
                            transform: translateX(0);
                            opacity: 1;
                        }
                 
                    .tile:hover span {
                        opacity: 1;
                        transform: translateY(0px);
                    }

                    .dots span:nth-child(1) {
                        transition-delay: 0.05s;
                    }

                    .dots span:nth-child(2) {
                        transition-delay: 0.1s;
                    }

                    .dots span:nth-child(3) {
                        transition-delay: 0.15s;
                    }


                    @media (max-width: 1000px) {
                        .wrap {
                            flex-direction: column;
                            width: 400px;
                        }
                    }

                    #title1 {
                        float: left;
                        margin-right: 20px;
                    }

                    #title2 {
                        float: left;
                        margin-right: 20px;
                    }

                    #title3 {
                        float: left;
                        margin-right: 20px;
                    }
                </style>
                <div class="wrap">
                    <div id=title1 class="tile">
                        <img src='images/pic01.jpg' />
                        <div class="text">
                            <h1 style="color:rgb(0, 0, 0); background-color: rgba( 255, 255, 255, 0.5 );text-align:center;">기숙사 합|불 예측</h1>        
                            <p class="animate-text">학생들의 기숙사 합|불을 가늠해 보는 공간입니다.</p>
                        </div>
                    </div>

                    <div id=title2 class="tile">
                        <img src='images/pic03.jpg' />
                        <div class="text">
                            <h1 style="color:rgb(0, 0, 0); background-color: rgba( 255, 255, 255, 0.5 );text-align:center;">강의평 쓰기</h1>
                            <p class="animate-text">수강한 과목에 대한 후기를 작성하여 강의정보를 공유하는 공간입니다.</p>
                        </div>
                    </div>

                    <div id=title3 class="tile">
                        <img src='images/pic02.jpg' />
                        <div class="text">
                            <h1 style="color:rgb(0, 0, 0); background-color: rgba( 255, 255, 255, 0.5 );text-align:center;">배달음식/31번 버스</h1>
                            <p class="animate-text">배달 음식점 메뉴,전화번호,최소배달 금액등을 한곳에 모아 빠른 주문이 가능합니다.  </p>
                            <p class="animate-text"> 31번 버스(모바일 이용시->승강장검색->'세명대'입력->정류장 선택시 실시간 위치 확인 가능합니다.) </p>
                        </div>
                    </div>
                </div>
        </div>
        
        <div id="jb-footer">
            <a id="smhome" href="http://www.semyung.ac.kr/kor.do">세명대학교 홈페이지 바로가기</a>
            <a id="smpor" href="http://setopia.semyung.ac.kr/main/index.jsp">세명대학교 포탈시스템 바로가기</a>
            <a id="smcom" href="http://www.semyung.ac.kr/scs.do">세명대학교 컴퓨터학부 과 홈페이지 바로가기</a>
        </div>
    </div>


    <div id="portfolio-wrapper">
        <div id="portfolio" class="container">
            <div class="title">
                <h2>세명대학교 컴퓨터학부 캡스톤 디자인 수업</h2>
                <span class="byline"></span>
            </div>
            <div class="column1">
                <div class="box">
                    <h3>Leader/Design</h3>
                    <p>ㅈㅅㅎ</p>
                    <a href="#" class="button">문의/이메일</a>
                </div>
            </div>
            <div class="column2">
                <div class="box">
                    <h3>.</h3>
                    <p>ㅅㅇㅅ</p>
                    <a href="#" class="button">문의/이메일</a>
                </div>
            </div>
            <div class="column3">
                <div class="box">
                    <h3>Data Base</h3>
                    <p>ㅊㅁㄱ</p>
                    <a href="#" class="button">문의/이메일</a>
                </div>
            </div>
            <div class="column4">
                <div class="box">
                    <h3>Main</h3>
                    <p>ㅈㅇㄱ</p>
                    <a href="#" class="button">문의/이메일</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>