<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class lecwriteController extends Controller
{
    public function index()
    {
        return view ('lecwrite') ;
    }
}