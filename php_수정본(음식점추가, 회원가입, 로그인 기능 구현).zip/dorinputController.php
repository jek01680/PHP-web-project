<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class dorinputController extends Controller
{
    public function index()
    {
        return view ('dorinput') ;
    }
}