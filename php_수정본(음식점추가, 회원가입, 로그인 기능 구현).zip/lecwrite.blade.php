﻿<!doctype html>
<!페이지 제목>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, minimum-scale=0.2, maximum-scale=0.3, user-scalable=yes" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="/css/default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="/css/fonts.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
    <div id="wrapper">
        <div id="header-wrapper">
            <head>
                <meta charset="utf-8" />
                <title>CSS</title>
                <style>
                    #header {
                        width: 1000px;
                        margin: 0px auto;
                    }

                    #logo {
                        font-family: Calibri;
                        font-style: italic;
                        font-weight: lighter;
                        margin-top: 300px;
                        margin-left: 250px;
                        width: 500px;
                    }
                    #menu {
                        width: 1000px;
                        text-align: center;
                        background-color: #1b6ef2;
                    }
                </style>

            </head>
            <div id="header" class="container">
                <div id="logo">
                    <h1><a href="#">'4' to 世明 </a></h1>
                    <p>by.computer science</p>
                </div>
            </div>
            <div id="menu" class="container">
                <ul>
                    <li class="current_page_item"><a href="intro.html"  accesskey="1" title="">home</a></li>
                    <li><a href="dorcount.html"  accesskey="2" title="">Dormitory</a></li>
                    <li><a href="lecevalu.html"  accesskey="3" title="">Lecture</a></li>
                    <li><a href="delivery.html" accesskey="4" title="">Delivery</a></li>
                    <li><a href="http://its.okjc.net/m01/map?category=1"  accesskey="5" title="">31'Bus</a></li>
                    <li><a href="login"  accesskey="6" title="">Sign In</a></li>
                    <li><a href="register"  accesskey="7" title="">Sign Up</a></li>
                </ul>
            </div>
        </div>
</body>

<!페이지 section>
    <style rel="stylesheet">
        body {
            background: -webkit-linear-gradient(45deg, rgba(66, 183, 245, 0.8) 0%, rgba(66, 245, 189, 0.4) 100%);
            background: linear-gradient(45deg, rgba(66, 183, 245, 0.8) 0%, rgba(66, 245, 189, 0.4) 100%);
        }
    </style>
    <style>
        #jb-container {
            width: 1160px;
            margin: 0px auto;
            padding: 20px;
            border: 1px solid #bcbcbc;
        }

        #jb-content {
            width: 860px;
            padding: 20px;
            margin-bottom: 20px;
            float: right;
            border: 1px solid #bcbcbc;
        }

        #jb-sidebar {
            width: 200px;
            padding: 20px;
            margin-bottom: 20px;
            float: left;
        }

        #jb-footer {
            clear: both;
            padding: 2px;
        }
    </style>

<body>
    <div id="jb-container">
        <div id="jb-content">
            <h2> 강의평 쓰기</h2>
            <hr style="width:860px; height:1px; color:#808080 "; />
            <div id="lecwriting"  style="float:left; margin-right:5px; width:465px; height:335px;">
                <form>
                    <table>
                        <tr height="1" bgcolor="#bbbbb "><td colspan="4"></td></tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td align="center">과목</td>
                            <td>
                                <select name="subject" style="width:150px;">
                                    <option>캡스톤 디자인(컴)</option>
                                    <option>컴파일러</option>
                                    <option>컴퓨터 시스템 구조</option>
                                </select>
                            </td>
                        </tr>
                        <tr height="1" bgcolor="#dddddd"><td colspan="4"></td></tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td align="center">담당교원</td>
                            <td>
                                <select name="professor" style="width:150px;">
                                    <option>신경섭</option>
                                    <option>김영필</option>
                                </select>
                            </td>
                            </tr>
                        <tr height="1" bgcolor="#dddddd"><td colspan="4"></td></tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td align="center">작성자</td>
                            <td><input name="title" size="0" maxlength="100"></td>
                            <td>&nbsp;</td>
                        </tr>
                       
                        <tr height="1" bgcolor="#dddddd"><td colspan="4"></td></tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td align="center">내용</td>
                            <td><textarea name="memo" cols="50" rows="13"></textarea></td>
                            <td>&nbsp;</td>
                        </tr>
                        <tr height="1" bgcolor="#dddddd"><td colspan="4"></td></tr>

                        <tr align="center">
                            <td>&nbsp;</td>
                            <td colspan="2">
                                <input type=button value="등록">
                                <input type=button value="취소">
                            <td>&nbsp;</td>
                        </tr>
                    </table>
                </form>
            </div>
            <div id="lecwritecaution" style="float:left;  width:385px; height:335px; border:2px solid #f1e020;">
                <p style="margin-left:20px; margin-bottom:5px; font-family:'Book Antiqua';font-weight:700; font-size:19px;">※정확한 과목명 및 담당교원 조회 방법※</p>
                <p>▷학사행정→학사관리→수업(수강)→개설강좌</p><p>&nbsp;&nbsp;&nbsp;(or 강의시간표 조회)</p>
                <p>▷수강신청 바로가기→개설강좌조회(or 수강신천내역조회)</p>
                <p style="margin-top:145px; margin-left:28px;">객관적이고 유익한 강의평 작성을 부탁드립니다 :)</p>
            </div>
        </div>

        <!수직메뉴바생성>
        <style>
            body {
                margin: 20px auto;
                padding: 0px;
                font-family: "맑은 고딕";
                font-size: 0.9em;
            }

            ul#navi {
                width: 200px;
                text-indent: 10px;
            }

                ul#navi, ul#navi ul {
                    margin: 0;
                    padding: 0;
                    list-style: none;
                }

            li.group {
                margin-bottom: 3px;
            }

                li.group div.title {
                    height: 35px;
                    line-height: 35px;
                    background: #f1e020;
                    cursor: pointer;
                }

            ul.sub li {
                margin-bottom: 2px;
                height: 35px;
                line-height: 35px;
                background: #f4f4f4;
                cursor: pointer;
            }

                ul.sub li a {
                    display: block;
                    width: 100%;
                    height: 100%;
                    text-decoration: none;
                    color: #000;
                }

                ul.sub li:hover {
                    background: #cf0;
                }
        </style>
        <div id="jb-sidebar">
            <ul id="navi">
                <li class="group">
                    <div class="title">강의</div>
                    <ul class="sub">
                        <li><a href="lecevalu.html">강의평</a></li>
                        <li><a href="http://setopia.semyung.ac.kr/main/index.jsp">포탈시스템 바로가기</a> </li>
                    </ul>

                </li>
            </ul>
        </div>
        <div id="jb-footer">

        </div>
    </div>

    <div id="portfolio-wrapper">
        <div id="portfolio" class="container">
            <div class="title">
                <h2>세명대학교 컴퓨터학부 캡스톤 디자인 수업</h2>
                <span class="byline"></span>
            </div>
            <div class="column1">
                <div class="box">
                    <h3>Leader/Design</h3>
                    <p>ㅈㅅㅎ</p>
                    <a href="#" class="button">문의/이메일</a>
                </div>
            </div>
            <div class="column2">
                <div class="box">
                    <h3>.</h3>
                    <p>ㅅㅇㅅ</p>
                    <a href="#" class="button">문의/이메일</a>
                </div>
            </div>
            <div class="column3">
                <div class="box">
                    <h3>Data Base</h3>
                    <p>ㅊㅁㄱ</p>
                    <a href="#" class="button">문의/이메일</a>
                </div>
            </div>
            <div class="column4">
                <div class="box">
                    <h3>Main</h3>
                    <p>ㅈㅇㄱ</p>
                    <a href="#" class="button">문의/이메일</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
