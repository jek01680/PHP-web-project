
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, minimum-scale=0.2, maximum-scale=0.3, user-scalable=yes" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" />
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
$(function () {
    $("#datepicker").datepicker();
});
    </script>

</head>
<body>
    <div id="wrapper">
        <div id="header-wrapper">
            <style>
#header {
width: 1000px;
                    margin: 0px auto;
                }

                #logo {
                    font-family: Calibri;
                    font-style: italic;
                    font-weight: lighter;
                    margin-top: 300px;
                    margin-left: 250px;
                    width: 500px;
                }
            </style>
            <style>
@import url('https://fonts.googleapis.com/css?family=Roboto');

                /*body 초기화*/
                #main-menu #sub-menu {
                    margin: 0;
                    padding: 0;
                    font-family: "Roboto", serif;
                    display: flex;
                    flex-flow: column nowrap;
                    justify-content: center;
                    align-items: center;
                    overflow-x: hidden;
                }

                h1 {
    margin: 2em 0 1.5em 0;
                }

                nav {
    width: 1020px;
                    height: 60px;
                    display: flex;
                    justify-content: center;
                    position: relative;
                    background: #382d51;
                    margin: auto;
                }

                ul, li {
    margin: 0;
    padding: 0;
    list-style: none;
                }

                #main-menu > li {
                    float: left;
                    position: relative;
                    width: 170px;
                    font-family: Calibri;
                }

                    #main-menu > li > a {
                        font-size: 22px;
                        color: rgba(255,255,255,0.85);
                        text-align: center;
                        text-decoration: none;
                        letter-spacing: 0.05em;
                        display: block;
                        padding: 14px 36px;
                        border-right: 1px solid rgba(0,0,0,0.15);
                        text-shadow: 1px 1px 1px rgba(0,0,0,0.2);
                    }

                    #main-menu > li:nth-child(1) > a {
                        border-left: 1px solid rgba(0,0,0,0.15);
                    }

                #sub-menu {
                    position: absolute;
                    background: rgba(140, 113, 202, 0.66);
                    opacity: 0;
                    visibility: hidden;
                    transition: all 0.15s ease-in;
                }

                    #sub-menu > li {
                        width: 170px;
                        padding: 16px 28px;
                        border-bottom: 1px solid rgba(0,0,0,0.15);
                        font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
                    }

                        #sub-menu > li > a {
                            color: rgba(255,255,255,0.6);
                            text-decoration: none;
                            display: block;
                        }

                #main-menu > li:hover #sub-menu {
                    opacity: 1;
                    visibility: visible;
                }

                #sub-menu > li > a:hover {
                    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
                    font-weight: 700;
                    color: #2d2441;
                }
            </style>
            <div id="header" class="container">
                <div id="logo">
                    <h1><a href="#">'4' to 世明 </a></h1>
                    <p>by.computer science</p>
                </div>
            </div>
            <nav role="navigation">
                <ul id="main-menu" class="container">
                    <li><a href="intro.html" accesskey="1" title="">Home</a></li>
                    <li>
                        <a href="dorcount.html" accesskey="2" title="">Dormitory</a>
                        <ul id="sub-menu">
                            <li><a href="dorcount.html">기숙사 합|불 예측</a></li>
                            <li><a href="dorinput.html">★기숙사 데이터 입력★</a></li>
                            <li><a href="http://www.semyung.ac.kr/kor/sub05_03_01.do">세명대학교 기숙사 안내</a></li>
                            <li><a href="http://www.semyung.ac.kr/cyber/index.html">세명대학교 사이버 투어</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="lecevalu.html" accesskey="3" title="">Lecture</a>
                        <ul id="sub-menu">
                            <li><a href="lecevalu.html">강의평</a></li>
                            <li><a href="http://setopia.semyung.ac.kr/main/index.jsp">포탈시스템 바로가기</a> </li>
                        </ul>
                    </li>
                    <li><a href="delivery.html" accesskey="4" title="">Delivery</a></li>
                    <li><a href="http://its.okjc.net/m01/map?category=1" accesskey="5" title="">31'Bus</a></li>
                    <li>
                        <a href="signin.html" accesskey="6" title="">sign in</a>
                        <ul id="sub-menu">
                            <li><a href="signin.html" accesskey="6" title="">로그인</a></li>
                            <li>
                                <a href="signup.html" accesskey="6" title="">
                                    회원가입
                                </a>
                            </li>

                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </body>
 <!페이지 section>
<style rel="stylesheet">
    body {
        background-color: #e8eeef;
    }
</style>
<style>
    #jb-container {
        width: 1160px;
        height: 700px;
        margin: 0px auto;
        padding: 20px;
        border: 1px solid #bcbcbc;
    }

    #jb-content {
        width: 500px;
        padding: 20px;
        margin: auto;
        margin-bottom: 20px;
        align-content: center;
    }

    .form-style-w3ls input[type="text"], .form-style-w3ls input[type="email"], .form-style-w3ls input[type="password"], select {
        outline: none;
        font-size: 14px;
        border: none;
        color: #666;
        background: #f1f1f1;
        letter-spacing: 0.5px;
        padding: 14px 20px;
        width: 100%;
        box-sizing: border-box;
        margin-bottom: 15px;
    }

    .form-style-w3ls button.btn {
        color: #fff;
        background: #382d51;
        border: none;
        padding: 14px 0;
        outline: none;
        border-radius: 0;
        width: 100%;
        font-size: 15px;
        cursor: pointer;
        letter-spacing: 1px;
        -webkit-transition: 0.5s all;
        -o-transition: 0.5s all;
        -moz-transition: 0.5s all;
        -ms-transition: 0.5s all;
        transition: 0.5s all;
    }

    .form-style-w3ls input[type="submit"]:hover {
        background: #dc3545;
    }

    .padding {
        padding: 2.5em;
        background: #fff;
    }

    .form-style-w3ls span {
        font-size: 13px;
        color: #666;
    }

        .form-style-w3ls span a {
            color: #3369e7;
        }
</style>
<body>
    <div id="jb-container">
        <div id="jb-content">
            <div class="padding">
                <form action="#" method="post">
                    <h2 class="mb-3">Sign Up</h2>
                    <div class="form-style-w3ls">
                        <form action="#" method="post">
                            <fieldset>
                                <p>
                                    <Label for="nickname">nickname </Label>
                                    <input placeholder="" id="nickname" type="text" name="#" required="" />
                                </p>
                                <p>
                                    <Label for="email">email</Label>
                                    <input placeholder="" id="email" type="email" name="#" required="" />
                                </p>
                                <p>
                                    <Label for="password">password </Label>
                                    <input placeholder="" id="password" type="password" name="#" required="" />
                                </p>
                                <p>
                                    <Label for="cpassword">password check </Label>
                                    <input placeholder="" id="cpassword" type="password" name="#" required="" />
                                </p>
                            </fieldset>
                            <p>
                                <button Class="btn" style="border:1px solid; margin-top:5px;">Sign Up</button>
                            </p>
                        </form>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="portfolio-wrapper">
        <div id="portfolio" class="container">
            <div class="title">
                <h2>세명대학교 컴퓨터학부 캡스톤 디자인 수업</h2>

            </div>
            <div class="column1">
                <div class="box">
                    <h3>Leader/Design</h3>
                    <p>ㅈㅅㅎ</p>
              
                </div>
            </div>
            <div class="column2">
                <div class="box">
                    <h3>.</h3>
                    <p>.</p>
                   
                </div>
            </div>
            <div class="column3">
                <div class="box">
                    <h3>Data Base</h3>
                    <p>ㅊㅁㄱ</p>
                  
                </div>
            </div>
            <div class="column4">
                <div class="box">
                    <h3>Main</h3>
                    <p>ㅈㅇㄱ</p>
                   
                </div>
            </div>
        </div>
    </div>
</body>
</html>