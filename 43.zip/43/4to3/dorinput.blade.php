<!doctype html>
<html lang="ko">
<!페이지 제목>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>

</head>
<body>
<div id="wrapper">
    <div id="header-wrapper">
        <style>
            #header {
                width: 1000px;
                margin: 0px auto;
            }

            #logo {
                font-family: Calibri;
                font-style: italic;
                font-weight: lighter;
                margin-top: 300px;
                margin-left: 250px;
                width: 500px;
            }
        </style>
        <style>
            @import url('https://fonts.googleapis.com/css?family=Roboto');

            /*body 초기화*/
            #main-menu #sub-menu {
                margin: 0;
                padding: 0;
                font-family: "Roboto", serif;
                display: flex;
                flex-flow: column nowrap;
                justify-content: center;
                align-items: center;
                overflow-x: hidden;
            }

            h1 {
                margin: 2em 0 1.5em 0;
            }

            nav {
                width: 1020px;
                height: 60px;
                display: flex;
                justify-content: center;
                position: relative;
                background: #382d51;
                margin: auto;
            }

            ul, li {
                margin: 0;
                padding: 0;
                list-style: none;
            }

            #main-menu > li {
                float: left;
                position: relative;
                width: 170px;
                font-family: Calibri;
            }

            #main-menu > li > a {
                font-size: 22px;
                color: rgba(255,255,255,0.85);
                text-align: center;
                text-decoration: none;
                letter-spacing: 0.05em;
                display: block;
                padding: 14px 36px;
                border-right: 1px solid rgba(0,0,0,0.15);
                text-shadow: 1px 1px 1px rgba(0,0,0,0.2);
            }

            #main-menu > li:nth-child(1) > a {
                border-left: 1px solid rgba(0,0,0,0.15);
            }

            #sub-menu {
                position: absolute;
                background: rgba(140, 113, 202, 0.66);
                opacity: 0;
                visibility: hidden;
                transition: all 0.15s ease-in;
            }

            #sub-menu > li {
                width: 170px;
                padding: 16px 28px;
                border-bottom: 1px solid rgba(0,0,0,0.15);
                font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            }

            #sub-menu > li > a {
                color: rgba(255,255,255,0.6);
                text-decoration: none;
                display: block;
            }

            #main-menu > li:hover #sub-menu {
                opacity: 1;
                visibility: visible;
            }

            #sub-menu > li > a:hover {
                font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
                font-weight: 700;
                color: #2d2441;
            }
        </style>
        <div id="header" class="container">
            <div id="logo">
                <h1><a href="#">'4' to 世明 </a></h1>
                <p>by.computer science</p>
            </div>
        </div>
        <nav role="navigation">
            <ul id="main-menu" class="container">
                <li><a href="intro.html" accesskey="1" title="">Home</a></li>
                <li>
                    <a href="dorcount.html" accesskey="2" title="">Dormitory</a>
                    <ul id="sub-menu">
                        <li><a href="dorcount.html">기숙사 합|불 예측</a></li>
                        <li><a href="dorinput.html">★기숙사 데이터 입력★</a></li>
                        <li><a href="http://www.semyung.ac.kr/kor/sub05_03_01.do">세명대학교 기숙사 안내</a></li>
                        <li><a href="http://www.semyung.ac.kr/cyber/index.html">세명대학교 사이버 투어</a></li>
                    </ul>
                </li>
                <li>
                    <a href="lecevalu.html" accesskey="3" title="">Lecture</a>
                    <ul id="sub-menu">
                        <li><a href="lecevalu.html">강의평</a></li>
                        <li><a href="http://setopia.semyung.ac.kr/main/index.jsp">포탈시스템 바로가기</a> </li>
                    </ul>
                </li>
                <li><a href="delivery.html" accesskey="4" title="">Delivery</a></li>
                <li><a href="http://its.okjc.net/m01/map?category=1" accesskey="5" title="">31'Bus</a></li>
                <li>
                    <a href="signin.html" accesskey="6" title="">sign in</a>
                    <ul id="sub-menu">
                        <li><a href="signin.html" accesskey="6" title="">로그인</a></li>
                        <li>
                            <a href="signup.html" accesskey="6" title="">
                                회원가입
                            </a>
                        </li>

                    </ul>
                </li>
            </ul>
        </nav>
    </div>

</body>

<!페이지 section>
<style rel="stylesheet">
    body {
        background-color: #e8eeef;
    }
</style>
<style>
    #jb-container {
        width: 1160px;
        margin: 0px auto;
        padding: 20px;
        border: 1px solid #bcbcbc;
    }

    #jb-content {
        width: 900px;
        height:900px;
        padding: 20px;
        margin: auto;
        border: 1px solid #bcbcbc;
    }


</style>
<style type="text/css">
    .form-style-4 {
        width: 500px;
        font-size: 16px;
        background: #e8eeef;
        padding: 30px 30px 15px 30px;
        margin:auto;

    }

    .form-style-4 input[type=reset],
    .form-style-4 input[type=select],
    .form-style-4 input[type=radio],
    .form-style-4 input[type=submit],
    .form-style-4 input[type=button],
    .form-style-4 input[type=text],
    .form-style-4 textarea,
    .form-style-4 label {
        font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
        font-size: 16px;
        color: black;
    }

    .form-style-4 label {
        display: block;

    }

    .form-style-4 label > span {
        display: inline-block;
        float: left;
        width: 200px;
    }

    .form-style-4 input[type=select],
    .form-style-4 input[type=radio],
    .form-style-4 input[type=text],
    .form-style-4 textarea {
        font-style:inherit;
        padding: 0px 0px 0px 0px;
        background: transparent;
        outline: none;
        border: none;
        border-bottom:2px solid #382d51;
        width: 275px;
        overflow: hidden;
        resize: none;
        height: 25px;
    }

    .form-style-4 textarea:focus,
    .form-style-4 input[type=radio]:focus,
    .form-style-4 input[type=text]:focus,
    .form-style-4 input[type=email]:focus,
    .form-style-4 input[type=email] :focus {
        border-bottom: 2px solid rgba(140, 113, 202, 0.66);
    }
    .form-style-4 input[type=reset],
    .form-style-4 input[type=submit],
    .form-style-4 input[type=button] {
        background: #382d51;
        border: none;
        padding: 8px 10px 8px 10px;
        border-radius: 5px;
        color: #fff;
        width: 150px;

    }
    .

    .form-style-4 input[type=reset]:hover,
    .form-style-4 input[type=submit]:hover,
    .form-style-4 input[type=button]:hover {
        background: rgba(140, 113, 202, 0.66);
    }
    #dorm{
        width: 200px;
        height:25px;
    }
    #more{
        height: 25px;
    }

</style>


<body>
<div id="jb-container">
    <div id="jb-content">
        <h2 style="text-align:center; margin-top:50px;">추가정보 입력</h2>
        <form class="form-style-4" name="more_form" method="post" action="more_print.php">
            <label for="dorm">
                <span>▷지원한 기숙사◁</span>
                <select name="dorm" id="dorm">
                    <optgroup label="청풍학사">
                        <option value="11">1인실</option>
                        <option value="12">2인실</option>
                    </optgroup>
                    <optgroup label="세명학사">
                        <option value="21">1인실</option>
                        <option value="22">2인실</option>
                        <option value="24">(2+2)인실</option>
                        <option value="26">(3+3)인실</option>
                    </optgroup>
                    <optgroup label="청룡학사">
                        <option value="32">2인실</option>
                        <option value="34">4인실</option>
                        <option value="36">(2+4)인실</option>
                    </optgroup>
                    <optgroup label="예지학사">
                        <option value="42">2인실</option>
                        <option value="43">3인실</option>
                        <option value="44">4인실</option>
                    </optgroup>
                    <optgroup label="인성학사">
                        <option value="51">1인실</option>
                        <option value="52">2인실</option>
                        <option value="56">(2+4)인실</option>
                    </optgroup>
                    <optgroup label="비룡학사">
                        <option value="61">1인실</option>
                        <option value="62">2인실</option>
                    </optgroup>
                </select><br />
            </label><br />
            <label for="more">
                <span>▷합불 및 추가 합격◁</span>
                <select id="more" name="more">
                    <option value="1" checked="checked">합격</option>
                    <option value="2">불합격</option>
                    <option value="3">추가 합격</option>
                </select>
            </label><br />
            &nbsp;

            <label for="grade">
                <span>1. 학점</span><input type="text" id="grade" name="grade" maxlength="4" placeholder="숫자만 입력" required="true">
            </label><br /><br />
            <label for="dorm_score">
                <span>2. 생활관 점수</span><input type="text" id="dorm_score" name="dorm_score" placeholder="상점벌점 합산 결과" required="true">
            </label><br /><br />
            <label for="money">
                <span>3. 소득분위</span><input type="text" id="money" name="money" maxlength="2" placeholder="숫자만 입력" required="true">
            </label><br /><br />
            <label for="home">
                <span >4. 거주지</span> <table>
                    <tr>
                        <td><input style="width:17px;height:17px" type="radio" id="home" name="home" value="14" checked="checked" /></td>
                        <td><p style="font-size:16px;">제천, 영월, 단양</p></td>
                    </tr>
                    <tr>
                        <td><input style=" width:17px;height:17px;" type="radio" id="home" name="home" value="16" />  </td>
                        <td><p style="font-size:15px;">원주, 충주</p></td>
                    </tr>
                    <tr>
                        <td><input style=" width:17px;height:17px;" type="radio" id="home" name="home" value="18" /> </td>
                        <td><p style="font-size:15px;">서울, 성남, 수원, 용인, 부천, 이천 등</p></td>
                    </tr>
                    <tr>
                        <td><input style=" width:17px;height:17px;x;" type="radio" id="home" name="home" value="20" />  </td>
                        <td><p style="font-size:15px;">그 외 지역</p></td>
                    </tr>
                </table>

            </label>
            <label>
                <input type="submit" value="저장" /><input type="reset" value="초기화" style="float: right">
            </label>
            <h6 style="text-align:center; font-size:12px;">추가로 입력된 정보는 데이터 베이스에 저장 되어 추후 정확도를 높이는데 도움을 줍니다.</h6>
        </form>
    </div>
</div>


<div id="portfolio-wrapper">
    <div id="portfolio" class="container">
        <div class="title">
            <h2>세명대학교 컴퓨터학부 캡스톤 디자인 수업</h2>
            <span class="byline">Ich habe alles alleine gemacht.</span>
        </div>
        <div class="column1">
            <div class="box">
                <h3>Leader/Design</h3>
                <p>ㅈㅅㅎ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column2">
            <div class="box">
                <h3>.</h3>
                <p>.</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column3">
            <div class="box">
                <h3>Data Base</h3>
                <p>ㅊㅁㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column4">
            <div class="box">
                <h3>Main</h3>
                <p>ㅈㅇㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>