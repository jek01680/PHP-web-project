<!doctype html>
<html lang="ko">
<!페이지 제목>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
    <script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>

</head>
<body>
<div id="wrapper">
    <div id="header-wrapper">
        <style>
            #header {
                width: 1000px;
                margin: 0px auto;
            }

            #logo {
                font-family: Calibri;
                font-style: italic;
                font-weight: lighter;
                margin-top: 300px;
                margin-left: 250px;
                width: 500px;
            }
        </style>
        <style>
            @import url('https://fonts.googleapis.com/css?family=Roboto');

            /*body 초기화*/
            #main-menu #sub-menu {
                margin: 0;
                padding: 0;
                font-family: "Roboto", serif;
                display: flex;
                flex-flow: column nowrap;
                justify-content: center;
                align-items: center;
                overflow-x: hidden;
            }

            h1 {
                margin: 2em 0 1.5em 0;
            }

            nav {
                width: 1020px;
                height: 60px;
                display: flex;
                justify-content: center;
                position: relative;
                background: #382d51;
                margin: auto;
            }

            ul, li {
                margin: 0;
                padding: 0;
                list-style: none;
            }

            #main-menu > li {
                float: left;
                position: relative;
                width: 170px;
                font-family: Calibri;
            }

            #main-menu > li > a {
                font-size: 22px;
                color: rgba(255,255,255,0.85);
                text-align: center;
                text-decoration: none;
                letter-spacing: 0.05em;
                display: block;
                padding: 14px 36px;
                border-right: 1px solid rgba(0,0,0,0.15);
                text-shadow: 1px 1px 1px rgba(0,0,0,0.2);
            }

            #main-menu > li:nth-child(1) > a {
                border-left: 1px solid rgba(0,0,0,0.15);
            }

            #sub-menu {
                position: absolute;
                background: rgba(140, 113, 202, 0.66);
                opacity: 0;
                visibility: hidden;
                transition: all 0.15s ease-in;
            }

            #sub-menu > li {
                width: 170px;
                padding: 16px 28px;
                border-bottom: 1px solid rgba(0,0,0,0.15);
                font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            }

            #sub-menu > li > a {
                color: rgba(255,255,255,0.6);
                text-decoration: none;
                display: block;
            }

            #main-menu > li:hover #sub-menu {
                opacity: 1;
                visibility: visible;
            }

            #sub-menu > li > a:hover {
                font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
                font-weight: 700;
                color: #2d2441;
            }
        </style>
        <div id="header" class="container">
            <div id="logo">
                <h1><a href="#">'4' to 世明 </a></h1>
                <p>by.computer science</p>
            </div>
        </div>
        <nav role="navigation">
            <ul id="main-menu" class="container">
                <li><a href="intro.html" accesskey="1" title="">Home</a></li>
                <li>
                    <a href="dorcount.html" accesskey="2" title="">Dormitory</a>
                    <ul id="sub-menu">
                        <li><a href="dorcount.html">기숙사 합|불 예측</a></li>
                        <li><a href="dorinput.html">★기숙사 데이터 입력★</a></li>
                        <li><a href="http://www.semyung.ac.kr/kor/sub05_03_01.do">세명대학교 기숙사 안내</a></li>
                        <li><a href="http://www.semyung.ac.kr/cyber/index.html">세명대학교 사이버 투어</a></li>
                    </ul>
                </li>
                <li>
                    <a href="lecevalu.html" accesskey="3" title="">Lecture</a>
                    <ul id="sub-menu">
                        <li><a href="lecevalu.html">강의평</a></li>
                        <li><a href="http://setopia.semyung.ac.kr/main/index.jsp">포탈시스템 바로가기</a> </li>
                    </ul>
                </li>
                <li><a href="delivery.html" accesskey="4" title="">Delivery</a></li>
                <li><a href="http://its.okjc.net/m01/map?category=1" accesskey="5" title="">31'Bus</a></li>
                <li>
                    <a href="signin.html" accesskey="6" title="">sign in</a>
                    <ul id="sub-menu">
                        <li><a href="signin.html" accesskey="6" title="">로그인</a></li>
                        <li>
                            <a href="signup.html" accesskey="6" title="">
                                회원가입
                            </a>
                        </li>

                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</body>
<!페이지 section>
<style rel="stylesheet">
    body {
        background-color: #e8eeef;
    }
</style>
<style>
    #jb-container {
        width: 1160px;
        margin: 0px auto;
        padding: 20px;
        border: 1px solid #bcbcbc;
    }

    #jb-content {
        width: 900px;
        height:1000px;
        padding: 20px;
        margin: auto;
        border: 1px solid #bcbcbc;
    }


</style>
<body>
<div id="jb-container">
    <div id="jb-content">
        <h2 style="text-align:center; margin-top:50px;"> 배달 음식 모음</h2>
        <!검색창>
        <style>
            form {
                position: relative;
                width: 1060px;
                margin: 10px auto;
            }

            .serch {
                background: #382d51;
                height: 50px;
            }

            .serch:after {
                content: "";
                clear: both;
                display: table
            }

            .serch form {
                width: auto;
                height: 23px;
                float: right;
                margin-right: 30px;
                margin-bottom: 5px;
            }

            .serch input {
                width: 150px;
                height: 26px;
                padding-left: 15px;
                border-radius: 42px;
                border: 2px solid #324b4e;
                background: #e8eeef;
                outline: none;
                position: relative;
                transition: .3s linear;
            }

            .serch input:focus {
                width: 200px;
            }

            .serch button {
                width: 42px;
                height: 42px;
                background: none;
                border: none;
                position: absolute;
                top: -2px;
                right: 0;
            }

            .serch button:before {
                content: "\f002";
                font-family: FontAwesome;
                color: #382d51;
            }

            #lecwritebutton {
                font-weight: 900;
                width: 100px;
                height: 32px;
                border-radius: 0px;
                margin: 10px 15px;
                color: #382d51;
            }
        </style>
        <div class="serch">
            <form name=" input" action="getid.jsp" method="get">
                <input type="text" placeholder="음식점 이름 입력">
                <button type="submit" value="검색"></button>
            </form>
        </div>
        <!table생성>
        <style>
            .lectable table {
                width: 800px;
                margin: 20px 0;
                border: 0;
            }

            .lectable th {
                font-weight: bold;
                background-color: #c3b7c3;
                color: #000;
            }

            .lectable, .lectable th, .lectable td {
                font-size: 0.95em;
                text-align: center;
                padding: 4px;
                border-collapse: collapse;
            }

            .lectable th, .lectable td {
                border: 1px solid #ffffff;
                border-width: 1px 0 1px 0
            }

            .lectable tr {
                border: 1px solid #ffffff;
                margin: 0px;
                padding: 0px;
            }

            .lectable tr:nth-child(odd) {
                background-color: #f7f7f7;
            }

            .lectable tr:nth-child(even) {
                background-color: #ffffff;
            }

            .black_overlay {
                display: none;
                position: absolute;
                top: 0%;
                left: 0%;
                width:100%;
                height:300%;
                background-color: black;
                z-index: 1001;
                opacity: .80;
                filter: alpha(opacity=80);
            }

            .white_content {
                display: none;
                position: absolute;
                top: 25%;
                left: 25%;
                width: 700px;
                height: 800px;
                padding: 16px;
                border: 1px solid orange;
                background-color: white;
                z-index: 1002;
                overflow: auto;
            }

            #light1 {
            }
        </style>
        <script>
            $(function () {
                $("#light1").draggable({ containment: "#wrapper", scroll: false });
                $("#light2").draggable({ containment: "#wrapper", scroll: false });
                $("#light3").draggable({ containment: "#wrapper", scroll: false });
                $("#light4").draggable({ containment: "#wrapper", scroll: false });
                $("#light5").draggable({ containment: "#wrapper", scroll: false });
                $("#light6").draggable({ containment: "#wrapper", scroll: false });
                $("#light7").draggable({ containment: "#wrapper", scroll: false });
                $("#light8").draggable({ containment: "#wrapper", scroll: false });
                $("#light9").draggable({ containment: "#wrapper", scroll: false });
                $("#light10").draggable({ containment: "#wrapper", scroll: false });
                $("#light11").draggable({ containment: "#wrapper", scroll: false });
                $("#light12").draggable({ containment: "#wrapper", scroll: false });
                $("#light13").draggable({ containment: "#wrapper", scroll: false });
                $("#light14").draggable({ containment: "#wrapper", scroll: false });
                $("#light15").draggable({ containment: "#wrapper", scroll: false });

            });
        </script>

        <table class="lectable">
            <tr>
                <th width="30px;">번호</th>
                <th width="180px;">음식점 이름</th>
                <th width="180px;">전화번호</th>
                <th width="40px;">위치</th>
                <th width="240px;">메뉴 바로가기</th>
                <th width="240px;">기타사항</th>
            </tr>
            <!--1-->
            <tr>
                <td>1</td>
                <td>굽자</td>
                <td>043-653-8426</td>
                <td>시내</td>
                <td>
                    <button href="javascript:goDetail();" onclick="document.getElementById('light1').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light1" class="white_content">
                        <img src="deliveryphoto/kooppja.jpg" />
                        <button style="float:right;" href="javascript:popupClose();" onclick="document.getElementById('light1').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>
                    <div id="fade" class="black_overlay"></div>
                </td>
                <td>15,000원 이상 배달 가능</td>
            </tr>
            <!--2-->
            <tr>
                <td>2</td>
                <td>꼬꼬숯불닭갈비</td>
                <td>043-646-8372</td>
                <td>시내</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light2').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light2" class="white_content">
                        <img src="deliveryphoto/coco.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light2').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td>배달시간: 11:00~21:00</td>
            </tr>
            <!--3-->
            <tr>
                <td>3</td>
                <td>누룽지 장작구이</td>
                <td>043-642-6005</td>
                <td>시내</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light3').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light3" class="white_content">
                        <img src="deliveryphoto/nulungji.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light3').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td>영업시간 17:00~1:00</td>
            </tr>
            <!--4-->
            <tr>
                <td>4</td>
                <td>네네치킨</td>
                <td>043-643-4479</td>
                <td>시내</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light4').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light4" class="white_content">
                        <img src="deliveryphoto/neanea.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light4').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td></td>
            </tr>
            <!--5-->
            <tr>
                <td>5</td>
                <td>대파불고기</td>
                <td>043-652-4586</td>
                <td>정문</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light5').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light5" class="white_content">
                        <img src="deliveryphoto/daepa.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light5').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td></td>
            </tr>
            <!--6-->
            <tr>
                <td>6</td>
                <td>대학로 인생밥집</td>
                <td>043-644-7770 </td>
                <td>후문</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light6').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light6" class="white_content">
                        <img src="deliveryphoto/insaeng.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light6').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td>1인분 배달 가능!</td>
            </tr>
            <!--7-->
            <tr>
                <td>7</td>
                <td>대학 반점</td>
                <td>043-648-3322</td>
                <td>정문</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light7').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light7" class="white_content">
                        <img src="deliveryphoto/deahak.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light7').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td></td>
            </tr>
            <!--8-->
            <tr>
                <td>8</td>
                <td>두진 주먹밥</td>
                <td>043-653-0133</td>
                <td>후문</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light8').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light8" class="white_content">
                        <img src="deliveryphoto/doojin.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light8').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td></td>
            </tr>
            <!--9-->
            <tr>
                <td>9</td>
                <td>만원의 행복</td>
                <td>043-647-9981</td>
                <td>시내</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light9').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light9" class="white_content">
                        <img src="deliveryphoto/happy.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light9').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td>20,000원 이상 배달 가능</td>
            </tr>
            <!--10-->
            <tr>
                <td>10</td>
                <td>맘스터치</td>
                <td>043-644-8824 </td>
                <td>후문</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light10').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light10" class="white_content">
                        <img src="deliveryphoto/moms.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light10').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td></td>
            </tr>
            <!--11-->
            <tr>
                <td>11</td>
                <td>미쳐버린 국물떡볶이</td>
                <td>043-652-9294</td>
                <td>후문</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light11').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light11" class="white_content">
                        <img src="deliveryphoto/gugmul.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light11').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td></td>
            </tr>
            <!--12-->
            <tr>
                <td>12</td>
                <td>미쳐버린 파닭</td>
                <td>043-652-9295</td>
                <td>후문</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light12').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light12" class="white_content">
                        <img src="deliveryphoto/padalg.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light12').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td>영업시간 17:00~2:00</td>
            </tr>
            <!--13-->
            <tr>
                <td>13</td>
                <td>미쳐버린 치밥</td>
                <td>043-652-9294</td>
                <td>후문</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light13').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light13" class="white_content">
                        <img src="deliveryphoto/chibab.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light13').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td></td>
            </tr>
            <!--14-->
            <tr>
                <td>14</td>
                <td>미투 피자&치킨</td>
                <td>043-643-2288</td>
                <td>정문</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light14').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light14" class="white_content">
                        <img src="deliveryphoto/mito.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light14').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td>영업시간 18:00~2:30</td>
            </tr>
            <!--15-->
            <tr>
                <td>15</td>
                <td>바보스</td>
                <td>043-644-4884</td>
                <td>시내</td>
                <td>
                    <button href="javascript:void(0)" onclick="document.getElementById('light15').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                    <div id="light15" class="white_content">
                        <img src="deliveryphoto/babos.jpg" />
                        <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light15').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                    </div>

                    <div id="fade" class="black_overlay"></div>
                </td>
                <td>20,000원 미만 주문시 배달비 추가</td>
            </tr>
        </table>
    </div>
</div>

<div id="portfolio-wrapper">
    <div id="portfolio" class="container">
        <div class="title">
            <h2>세명대학교 컴퓨터학부 캡스톤 디자인 수업</h2>
            <span class="byline"></span>
        </div>
        <div class="column1">
            <div class="box">
                <h3>Leader/Design</h3>
                <p>ㅈㅅㅎ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column2">
            <div class="box">
                <h3>.</h3>
                <p>.</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column3">
            <div class="box">
                <h3>Data Base</h3>
                <p>ㅊㅁㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column4">
            <div class="box">
                <h3>Main</h3>
                <p>ㅈㅇㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>