<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, minimum-scale=0.2, maximum-scale=0.3, user-scalable=yes" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="header-wrapper">
    <style>
        #header {
            width: 1000px;
            margin: 0px auto;
        }

        #logo {
            font-family: Calibri;
            font-style: italic;
            font-weight: lighter;
            margin-top: 300px;
            margin-left: 250px;
            width: 500px;
        }

        #menu {
            width: 1000px;
            text-align: center;
            background-color: #382d51;
        }
    </style>
    <div id="header" class="container">
        <div id="logo">
            <h1><a href="#">'4' to 世明 </a></h1>
            <p>by.computer science</p>
        </div>
    </div>
    <div id="menu" class="container">
        <ul>
            <li class="current_page_item"><a href="intro.html" accesskey="1" title="">home</a></li>
            <li><a href="dorcount.html" accesskey="2" title="">Dormitory</a></li>
            <li><a href="lecevalu.html" accesskey="3" title="">Lecture</a></li>
            <li><a href="delivery.html" accesskey="4" title="">Delivery</a></li>
            <li><a href="http://its.okjc.net/m01/map?category=1" accesskey="5" title="">31'Bus</a></li>
            <li><a href="signin.html" accesskey="6" title="">sign in/sign up</a></li>
        </ul>
    </div>
</div>
</body>
</html>
