<!doctype html>
<!페이지 제목>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, minimum-scale=0.2, maximum-scale=0.3, user-scalable=yes" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
    <link href="default_ie6.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="wrapper">
    <div id="header-wrapper">
        <style>
            #header {
                width: 1000px;
                margin: 0px auto;
            }

            #logo {
                font-family: Calibri;
                font-style: italic;
                font-weight: lighter;
                margin-top: 300px;
                margin-left: 250px;
                width: 500px;
            }
        </style>
        <style>
            @import url('https://fonts.googleapis.com/css?family=Roboto');

            /*body 초기화*/
            #main-menu #sub-menu {
                margin: 0;
                padding: 0;
                font-family: "Roboto", serif;
                display: flex;
                flex-flow: column nowrap;
                justify-content: center;
                align-items: center;
                overflow-x: hidden;
            }

            h1 {
                margin: 2em 0 1.5em 0;
            }

            nav {
                width: 1020px;
                height: 60px;
                display: flex;
                justify-content: center;
                position: relative;
                background: #382d51;
                margin: auto;
            }

            ul, li {
                margin: 0;
                padding: 0;
                list-style: none;
            }

            #main-menu > li {
                float: left;
                position: relative;
                width: 170px;
                font-family: Calibri;
            }

            #main-menu > li > a {
                font-size: 22px;
                color: rgba(255,255,255,0.85);
                text-align: center;
                text-decoration: none;
                letter-spacing: 0.05em;
                display: block;
                padding: 14px 36px;
                border-right: 1px solid rgba(0,0,0,0.15);
                text-shadow: 1px 1px 1px rgba(0,0,0,0.2);
            }

            #main-menu > li:nth-child(1) > a {
                border-left: 1px solid rgba(0,0,0,0.15);
            }

            #sub-menu {
                position: absolute;
                background: rgba(140, 113, 202, 0.66);
                opacity: 0;
                visibility: hidden;
                transition: all 0.15s ease-in;
            }

            #sub-menu > li {
                width: 170px;
                padding: 16px 28px;
                border-bottom: 1px solid rgba(0,0,0,0.15);
                font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            }

            #sub-menu > li > a {
                color: rgba(255,255,255,0.6);
                text-decoration: none;
                display: block;
            }

            #main-menu > li:hover #sub-menu {
                opacity: 1;
                visibility: visible;
            }

            #sub-menu > li > a:hover {
                font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
                font-weight: 700;
                color: #2d2441;
            }
        </style>
        <div id="header" class="container">
            <div id="logo">
                <h1><a href="#">'4' to 世明 </a></h1>
                <p>by.computer science</p>
            </div>
        </div>
        <nav role="navigation">
            <ul id="main-menu" class="container">
                <li><a href="intro.html" accesskey="1" title="">Home</a></li>
                <li>
                    <a href="dorcount.html" accesskey="2" title="">Dormitory</a>
                    <ul id="sub-menu">
                        <li><a href="dorcount.html">기숙사 합|불 예측</a></li>
                        <li><a href="dorinput.html">★기숙사 데이터 입력★</a></li>
                        <li><a href="http://www.semyung.ac.kr/kor/sub05_03_01.do">세명대학교 기숙사 안내</a></li>
                        <li><a href="http://www.semyung.ac.kr/cyber/index.html">세명대학교 사이버 투어</a></li>
                    </ul>
                </li>
                <li>
                    <a href="lecevalu.html" accesskey="3" title="">Lecture</a>
                    <ul id="sub-menu">
                        <li><a href="lecevalu.html">강의평</a></li>
                        <li><a href="http://setopia.semyung.ac.kr/main/index.jsp">포탈시스템 바로가기</a> </li>
                    </ul>
                </li>
                <li><a href="delivery.html" accesskey="4" title="">Delivery</a></li>
                <li><a href="http://its.okjc.net/m01/map?category=1" accesskey="5" title="">31'Bus</a></li>
                <li>
                    <a href="signin.html" accesskey="6" title="">sign in</a>
                    <ul id="sub-menu">
                        <li><a href="signin.html" accesskey="6" title="">로그인</a></li>
                        <li>
                            <a href="signup.html" accesskey="6" title="">
                                회원가입
                            </a>
                        </li>

                    </ul>
                </li>
            </ul>
        </nav>
    </div>


</body>

<!페이지 section>
<style rel="stylesheet">
    body {
        background-color: #e8eeef;
    }
</style>
<style>
    #jb-container {
        width: 1160px;
        margin: 0px auto;
        padding: 20px;
        border: 1px solid #bcbcbc;
    }

    #jb-content {
        width: 900px;
        height:600px;
        padding: 20px;
        margin: auto;
        border: 1px solid #bcbcbc;
    }

    #jb-footer {
        clear: both;
        padding: 2px;
    }
</style>

<body>
<div id="jb-container">
    <div id="jb-content">
        <h2 style="text-align:center; margin-top:50px;"> 강의평</h2>

        <!검색창>
        <style>
            form {
                position: relative;
                width: 1060px;
                margin: 10px auto;
            }

            .serch {
                background: #382d51;
                height:50px;
            }

            .serch:after {
                content: "";
                clear: both;
                display: table
            }

            .serch form {
                width: auto;
                height:23px;
                float: right;
                margin-right: 30px;
                margin-bottom:5px;
            }

            .serch input {
                width: 100px;
                height: 26px;
                padding-left: 15px;
                border-radius: 42px;
                border: 2px solid #324b4e;
                background: #e8eeef;
                outline: none;
                position:relative;
                transition: .3s linear;

            }

            .serch input:focus {
                width: 150px;
            }

            .serch button {
                width: 42px;
                height: 42px;
                background: none;
                border: none;
                position: absolute;
                top: -2px;
                right: 0;

            }
            .serch button:before {
                content: "\f002";
                font-family: FontAwesome;
                color: #382d51;
            }
            #lecwritebutton {
                font-weight: 900;
                width: 100px;
                height: 32px;
                border-radius: 0px;
                margin: 10px 15px;
                color: #382d51;
            }
        </style>
        <div class="serch">
            <input id="lecwritebutton"   type="button" value="강의평 쓰기" onclick="location.href='lecwrite.html'">
            <form class="find" name=" input" action="getid.jsp" method="get">

                <input type="text" placeholder="교원 입력">
                <button type="submit" value="검색"></button>
            </form>
            <form class="find" name=" input" action="getid.jsp" method="get">

                <input type="text" placeholder="과목 입력">
                <button type="submit" value="검색"></button>
            </form>
        </div>
        <!게시판-table>
        <style>
            .lectable table {
                width: 1060px;
                margin: 20px 0;
                border: 0;
            }

            .lectable th {
                font-weight: bold;
                background-color: #c3b7c3;
                color: #000;
            }

            .lectable, .lectable th, .lectable td {
                font-size: 0.95em;
                text-align: center;
                padding: 5px;
                border-collapse: collapse;
            }

            .lectable th, .lectable td {
                border: 1px solid #ffffff;
                border-width: 1px 0 1px 0
            }

            .lectable tr {
                border: 1px solid #ffffff;
                margin: 0px;
                padding: 0px;
            }

            .lectable tr:nth-child(odd) {
                background-color: #f7f7f7;
            }

            .lectable tr:nth-child(even) {
                background-color: #ffffff;
            }
        </style>
        <table class=lectable>
            <tr>
                <th width="50px;">번호</th>
                <th width="150px;">과목명</th>
                <th width="200px;">담당교원</th>
                <th width="130px;">작성자</th>
                <th width="330px;">후기</th>

            </tr>
            <tr>
                <td>1</td>
                <td>캡스톤 디자인</td>
                <td>신경섭</td>
                <td>관리자1</td>
                <td>123</td>

            </tr>
            <tr>
                <td>2</td>
                <td>컴파일러</td>
                <td>김영필</td>
                <td>관리자1</td>
                <td>123</td>

            </tr>
            <tr>
                <td>SAMPLE</td>
                <td>SAMPLE</td>
                <td>SAMPLE</td>
            </tr>
            <tr>
                <td>SAMPLE</td>
                <td>SAMPLE</td>
                <td>SAMPLE</td>
            </tr>
        </table>
    </div>


    <div id="jb-footer">
        <P style="margin:auto;margin-left:190px;color:midnightblue;">강의 평 작성시 '각자에게 유용한 정보를 나눔하는 곳'이라는 마음으로 자세하고 객관적인 강의평 작성을 부탁드립니다. </P>
    </div>
</div>

<div id="portfolio-wrapper">
    <div id="portfolio" class="container">
        <div class="title">
            <h2>세명대학교 컴퓨터학부 캡스톤 디자인 수업</h2>
            <span class="byline"></span>
        </div>
        <div class="column1">
            <div class="box">
                <h3>Leader/Design</h3>
                <p>ㅈㅅㅎ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column2">
            <div class="box">
                <h3>.</h3>
                <p>.</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column3">
            <div class="box">
                <h3>Data Base</h3>
                <p>ㅊㅁㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column4">
            <div class="box">
                <h3>Main</h3>
                <p>ㅈㅇㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>