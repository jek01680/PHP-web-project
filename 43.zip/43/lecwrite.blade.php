﻿<!doctype html>
<!페이지 제목>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, minimum-scale=0.2, maximum-scale=0.3, user-scalable=yes" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
    <div id="wrapper">
        <div id="header-wrapper">
            <style>
                #header {
                    width: 1000px;
                    margin: 0px auto;
                }

                #logo {
                    font-family: Calibri;
                    font-style: italic;
                    font-weight: lighter;
                    margin-top: 300px;
                    margin-left: 250px;
                    width: 500px;
                }
            </style>
            <style>
                @import url('https://fonts.googleapis.com/css?family=Roboto');

                /*body 초기화*/
                #main-menu #sub-menu {
                    margin: 0;
                    padding: 0;
                    font-family: "Roboto", serif;
                    display: flex;
                    flex-flow: column nowrap;
                    justify-content: center;
                    align-items: center;
                    overflow-x: hidden;
                }

                h1 {
                    margin: 2em 0 1.5em 0;
                }

                nav {
                    width: 1020px;
                    height: 60px;
                    display: flex;
                    justify-content: center;
                    position: relative;
                    background: #382d51;
                    margin: auto;
                }

                ul, li {
                    margin: 0;
                    padding: 0;
                    list-style: none;
                }

                #main-menu > li {
                    float: left;
                    position: relative;
                    width: 170px;
                    font-family: Calibri;
                }

                    #main-menu > li > a {
                        font-size: 22px;
                        color: rgba(255,255,255,0.85);
                        text-align: center;
                        text-decoration: none;
                        letter-spacing: 0.05em;
                        display: block;
                        padding: 14px 36px;
                        border-right: 1px solid rgba(0,0,0,0.15);
                        text-shadow: 1px 1px 1px rgba(0,0,0,0.2);
                    }

                    #main-menu > li:nth-child(1) > a {
                        border-left: 1px solid rgba(0,0,0,0.15);
                    }

                #sub-menu {
                    position: absolute;
                    background: rgba(140, 113, 202, 0.66);
                    opacity: 0;
                    visibility: hidden;
                    transition: all 0.15s ease-in;
                }

                    #sub-menu > li {
                        width: 170px;
                        padding: 16px 28px;
                        border-bottom: 1px solid rgba(0,0,0,0.15);
                        font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
                    }

                        #sub-menu > li > a {
                            color: rgba(255,255,255,0.6);
                            text-decoration: none;
                            display: block;
                        }

                #main-menu > li:hover #sub-menu {
                    opacity: 1;
                    visibility: visible;
                }

                #sub-menu > li > a:hover {
                    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
                    font-weight: 700;
                    color: #2d2441;
                }
            </style>
            <div id="header" class="container">
                <div id="logo">
                    <h1><a href="#">'4' to 世明 </a></h1>
                    <p>by.computer science</p>
                </div>
            </div>
            <nav role="navigation">
                <ul id="main-menu" class="container">
                    <li><a href="intro.html" accesskey="1" title="">Home</a></li>
                    <li>
                        <a href="dorcount.html" accesskey="2" title="">Dormitory</a>
                        <ul id="sub-menu">
                            <li><a href="dorcount.html">기숙사 합|불 예측</a></li>
                            <li><a href="dorinput.html">★기숙사 데이터 입력★</a></li>
                            <li><a href="http://www.semyung.ac.kr/kor/sub05_03_01.do">세명대학교 기숙사 안내</a></li>
                            <li><a href="http://www.semyung.ac.kr/cyber/index.html">세명대학교 사이버 투어</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="lecevalu.html" accesskey="3" title="">Lecture</a>
                        <ul id="sub-menu">
                            <li><a href="lecevalu.html">강의평</a></li>
                            <li><a href="http://setopia.semyung.ac.kr/main/index.jsp">포탈시스템 바로가기</a> </li>
                        </ul>
                    </li>
                    <li><a href="delivery.html" accesskey="4" title="">Delivery</a></li>
                    <li><a href="http://its.okjc.net/m01/map?category=1" accesskey="5" title="">31'Bus</a></li>
                    <li>
                        <a href="signin.html" accesskey="6" title="">sign in</a>
                        <ul id="sub-menu">
                            <li><a href="signin.html" accesskey="6" title="">로그인</a></li>
                            <li>
                                <a href="signup.html" accesskey="6" title="">
                                    회원가입
                                </a>
                            </li>

                        </ul>
                    </li>
                </ul>
            </nav>
        </div>


</body>

<!페이지 section>
<style rel="stylesheet">
    body {
        background-color: #e8eeef;
    }
</style>
<style>
    #jb-container {
        width: 1160px;
        margin: 0px auto;
        padding: 20px;
        border: 1px solid #bcbcbc;
    }

    #jb-content {
        width: 900px;
        height:500px;
        padding: 20px;
        margin: auto;
        border: 1px solid #bcbcbc;
    }


    #jb-footer {
        clear: both;
        padding: 2px;
    }
</style>

<body>
    <div id="jb-container">
        <div id="jb-content">
            <h2 style="text-align:center; margin-top:50px;"> 강의평 쓰기</h2>
            <hr style="width:860px; height:1px; color:#808080 " ; />
            <div id="lecwriting" style="float:left; margin-right:5px; width:465px; height:335px;">
                <form>
                    <table>
                        <tr height="1" bgcolor="#bbbbb "><td colspan="4"></td></tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td align="center">과목</td>
                            <td>
                                <select name="subject" style="width:150px;">
                                    <option>캡스톤 디자인(컴)</option>
                                    <option>컴파일러</option>
                                    <option>컴퓨터 시스템 구조</option>
                                </select>
                            </td>
                        </tr>
                        <tr height="1" bgcolor="#dddddd"><td colspan="4"></td></tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td align="center">담당교원</td>
                            <td>
                                <select name="professor" style="width:150px;">
                                    <option>신경섭</option>
                                    <option>김영필</option>
                                </select>
                            </td>
                        </tr>
                        <tr height="1" bgcolor="#dddddd"><td colspan="4"></td></tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td align="center">작성자</td>
                            <td><input name="title" size="0" maxlength="100"></td>
                            <td>&nbsp;</td>
                        </tr>

                        <tr height="1" bgcolor="#dddddd"><td colspan="4"></td></tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td align="center">내용</td>
                            <td><textarea name="memo" cols="50" rows="13"></textarea></td>
                            <td>&nbsp;</td>
                        </tr>
                        <tr height="1" bgcolor="#dddddd"><td colspan="4"></td></tr>

                        <tr align="center">
                            <td>&nbsp;</td>
                            <td colspan="2">
                                <input type=button value="등록">
                                <input type=button value="취소">
                            <td>&nbsp;</td>
                        </tr>
                    </table>
                </form>
            </div>
            <div id="lecwritecaution" style="float:left;  width:385px; height:335px; border:2px solid #f1e020;">
                <p style="margin-left:20px; margin-bottom:5px; font-family:'Book Antiqua';font-weight:700; font-size:19px;">※정확한 과목명 및 담당교원 조회 방법※</p>
                <p>▷학사행정→학사관리→수업(수강)→개설강좌</p><p>&nbsp;&nbsp;&nbsp;(or 강의시간표 조회)</p>
                <p>▷수강신청 바로가기→개설강좌조회(or 수강신천내역조회)</p>
                <p style="margin-top:130px; margin-left:28px;">객관적이고 유익한 강의평 작성을 부탁드립니다 :)</p>
            </div>
        </div>

   
        <div id="jb-footer">

        </div>
    </div>

    <div id="portfolio-wrapper">
        <div id="portfolio" class="container">
            <div class="title">
                <h2>세명대학교 컴퓨터학부 캡스톤 디자인 수업</h2>
                <span class="byline"></span>
            </div>
            <div class="column1">
                <div class="box">
                    <h3>Leader/Design</h3>
                    <p>ㅈㅅㅎ</p>

                </div>
            </div>
            <div class="column2">
                <div class="box">
                    <h3>.</h3>
                    <p>.</p>

                </div>
            </div>
            <div class="column3">
                <div class="box">
                    <h3>Data Base</h3>
                    <p>ㅊㅁㄱ</p>

                </div>
            </div>
            <div class="column4">
                <div class="box">
                    <h3>Main</h3>
                    <p>ㅈㅇㄱ</p>

                </div>
            </div>
        </div>
    </div>
</body>
</html>