<!doctype html>
<html lang="ko">
<!페이지 제목>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, minimum-scale=0.2, maximum-scale=0.3, user-scalable=yes" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
</head>
<body>
<div id="wrapper">
    <div id="header-wrapper">
        <head>
            <meta charset="utf-8" />
            <title>CSS</title>
            <style>
                #header {
                    width: 1000px;
                    margin: 0px auto;
                }

                #logo {
                    font-family: Calibri;
                    font-style: italic;
                    font-weight: lighter;
                    margin-top: 300px;
                    margin-left: 250px;
                    width: 500px;
                }
            </style>
        </head>
        <div id="header" class="container">
            <div id="logo">
                <h1><a href="#">'4' to 世明 </a></h1>
                <p>by.computer science</p>
            </div>
        </div>
        <style>
            #menu {
                width: 1000px;
                text-align: center;
                background-color: #1b6ef2;
            }
        </style>
        <div id="menu" class="container">
            <ul>
                <li class="current_page_item"><a href="intro.html"  accesskey="1" title="">home</a></li>
                <li><a href="dorcount.html"  accesskey="2" title="">Dormitory</a></li>
                <li><a href="lecevalu.html"  accesskey="3" title="">Lecture</a></li>
                <li><a href="delivery.html" accesskey="4" title="">Delivery</a></li>
                <li><a href="http://its.okjc.net/m01/map?category=1"  accesskey="5" title="">31'Bus</a></li>
                <li><a href="signin.html"  accesskey="6" title="">sign in/sign up</a></li>
            </ul>
        </div>
    </div>
</body>

<!페이지 section>
    <style>
        #jb-container {
            width: 1160px;
            margin: 0px auto;
            padding: 20px;
            border: 1px solid #bcbcbc;
        }
        #jb-content {
            width: 860px;
            padding: 20px;
            margin-bottom: 20px;
            float: right;
            border: 1px solid #bcbcbc;
        }
        #jb-sidebar {
            width: 200px;
            padding: 20px;
            margin-bottom: 20px;
            float: left;
        }
        #jb-footer {
            clear: both;
            padding: 5px;
            border: 1px solid #bcbcbc;
        }
    </style>
<style type="text/css">
    .form-style-4 {
        width: 500px;
        font-size: 16px;
        background: #f4fcff;
        padding: 30px 30px 15px 30px;
        margin-left: 135px;
        border: 5px solid #1cc7a5;
    }
    .form-style-4 input[type=reset],
    .form-style-4 input[type=select],
    .form-style-4 input[type=radio],
    .form-style-4 input[type=submit],
    .form-style-4 input[type=button],
    .form-style-4 input[type=text],
    .form-style-4 textarea,
    .form-style-4 label {
        font-family: Georgia, Calibri,"Times New Roman", Times, serif;
        font-size: 16px;
        color: #000000;
    }

    .form-style-4 label {
        display: block;
        margin-bottom: 15px;
    }

    .form-style-4 label > span {
        display: inline-block;
        float: left;
        width: 150px;
    }
    .form-style-4 input[type=select],
    .form-style-4 input[type=radio],
    .form-style-4 input[type=text],
    .form-style-4 textarea {
        font-style: normal;
        padding: 0px 0px 0px 0px;
        background: transparent;
        outline: none;
        border: none;
        border-bottom: 1px dashed #1cc7a5;
        width: 275px;
        font-family: Georgia, Calibri,"Times New Roman", Times, serif;
        overflow: hidden;
        resize: none;
        height: 20px;
    }

    .form-style-4 input[type=text]:focus{
        border-bottom: 1px dashed #c15828;
    }
    .form-style-4 input[type=reset],
    .form-style-4 input[type=submit],
    .form-style-4 input[type=button] {
        background: #1cc7a5;
        border: none;
        padding: 10px 10px 10px 10px;
        width:100px;
        border-radius: 5px;
        color: #f4fcff;
    }
    .form-style-4 input[type=reset]:hover,
    .form-style-4 input[type=submit]:hover,
    .form-style-4 input[type=button]:hover {
        background: #15977d;
    }
</style>
<body>
<div id="jb-container">
    <div id="jb-content">
        <h2 style="text-align:center ">추가정보 입력</h2>
        <form class="form-style-4" name="more_form" method="post" action="more_print.php" >
            <label for="grade">
                <span style="position:relative;left:20px;">학점</span><input type="text" id="grade" name="grade" style="position:relative;left:-5px;" maxlength="4" placeholder="숫자만 입력" required="true">
            </label><br/>
            <label for="dorm_score">
                <span>생활관 점수</span><input type="text" id="dorm_score" name="dorm_score" style="position:relative;left:-5px;" placeholder="상점벌점 합산 결과" required="true">
            </label><br/>

            <label for="money">
                <span style="position:relative;left:10px;">소득분위</span><input type="text" id="money" name="money"  maxlength="2"style="position:relative;left:-5px;" placeholder="숫자만 입력"required="true">
            </label><br/>
            <label for="home"style="position:relative;left:15px;">거주지
                <table>
                    <tr>
                        <td><input style=" width:15px;height:15px;border:1px;position:relative;left:130px;top:-35px;" type="radio" id="home" name="home" value="14" checked="checked" />  </td>
                        <td><p style="font-size:17px;position:relative;left:130px;top:-28px;">제천, 영월, 단양</p></td>
                    </tr>
                    <tr>
                        <td><input style="width:17px;height:17px;border:1px;position:relative;left:130px;top:-35px;" type="radio" id="home" name="home" value="16" />  </td>
                        <td><p style="font-size:17px;position:relative;left:130px;top:-28px;">원주, 충주</p></td>
                    </tr>
                    <tr>
                        <td><input style=" width:17px;height:17px;border:1px;position:relative;left:130px;top:-35px;" type="radio" id="home" name="home" value="18" /> </td>
                        <td><p style="font-size:17px;position:relative;left:130px;top:-28px;">서울, 성남, 수원, 용인, 부천, 이천 등</p></td>
                    </tr>
                    <tr>
                        <td><input style=" width:17px;height:17px;border:1px;position:relative;left:130px;top:-35px;" type="radio" id="home" name="home" value="20" />  </td>
                        <td><p style="font-size:17px;position:relative;left:130px;top:-28px;">그 외 지역</p></td>
                    </tr>
                </table></label>
            <label for="dorm"style="position:relative;left:14px;top:-30px;">기숙사
                <select name="dorm" id="dorm" style="position:relative;left:85px;">
                    <optgroup label="청풍학사">
                        <option value="11" >1인실</option>
                        <option value="12">2인실</option>
                    </optgroup>
                    <optgroup label="세명학사">
                        <option value="21">1인실</option>
                        <option value="22">2인실</option>
                        <option value="24">(2+2)인실</option>
                        <option value="26">(3+3)인실</option>
                    </optgroup>
                    <optgroup label="청룡학사">
                        <option value="32">2인실</option>
                        <option value="34">4인실</option>
                        <option value="36">(2+4)인실</option>
                    </optgroup>
                    <optgroup label="예지학사">
                        <option value="42">2인실</option>
                        <option value="43">3인실</option>
                        <option value="44">4인실</option>
                    </optgroup>
                    <optgroup label="인성학사">
                        <option value="51">1인실</option>
                        <option value="52">2인실</option>
                        <option value="56">(2+4)인실</option>
                    </optgroup>
                    <optgroup label="비룡학사">
                        <option value="61">1인실</option>
                        <option value="62">2인실</option>
                    </optgroup>
                </select><br/>
                </fieldset>
            </label><br/>
            <label for="more"style="position:relative;top:-30px;">
                <span style="position:relative;left:-13px;">합불 및 추가합격</span>
                <select id="more" name="more">
                    <option value="1" checked="checked">합격</option>
                    <option value="2">불합격</option>
                    <option value="3">추가 합격</option>
                    </optgroup>
                </select>

            </label><br/>
            <label>
                <input type="submit" value="저장"style="position:relative;left:70px;top:-20px;"/><input type="reset" value="초기화" style="position:relative;left:220px;top:-20px;">
            </label>
        </form>
        <br/>
        <h5 style="text-align: center;">추가로 입력된 정보는 데이터 베이스에 저장 되어 추후 정확도를 높이는데 도움을 줍니다.</h5>
    </div>

    <!수직메뉴바생성>

    <style>
        body {
            margin: 20px auto;
            padding: 0;
            font-family: "맑은 고딕";
            font-size: 0.9em;
        }

        ul#navi {
            width: 200px;
            text-indent: 10px;
        }

        ul#navi, ul#navi ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }

        li.group {
            margin-bottom: 3px;
        }

        li.group div.title {
            height: 35px;
            line-height: 35px;
            background: #f1e020;
            cursor: pointer;
        }

        ul.sub li {
            margin-bottom: 2px;
            height: 35px;
            line-height: 35px;
            background: #f4f4f4;
            cursor: pointer;
        }

        ul.sub li a {
            display: block;
            width: 100%;
            height: 100%;
            text-decoration: none;
            color: #000;
        }

        ul.sub li:hover {
            background: #cf0;
        }

        #smdor {
            color: midnightblue;
            margin-left: 340px;
            margin-right: 100px;
            font-size: 1.2em;
            text-decoration: none;
        }

        #smcyb {
            color: midnightblue;
            font-size: 1.2em;
            text-decoration: none;
        }
    </style>
    <div id="jb-sidebar">
        <ul id="navi">
            <li class="group">
                <div class="title">기숙사</div>
                <ul class="sub">
                    <li><a href="dorcount.html">기숙사 합|불 예측</a></li>
                    <li><a href="dorinput.html">★기숙사 데이터 입력★</a> </li>
                    <li><a href="http://www.semyung.ac.kr/kor/sub05_03_01.do" >기숙사 안내 바로가기</a></li>
                    <li><a href="http://www.semyung.ac.kr/cyber/index.html">기숙사 사이버 투어</a> </li>
                </ul>
            </li>
        </ul>
    </div>
    <div id="jb-footer">
</div>

<div id="portfolio-wrapper">
    <div id="portfolio" class="container">
        <div class="title">
            <h2>세명대학교 컴퓨터학부 캡스톤 디자인 수업</h2>
            <span class="byline">Ich habe alles alleine gemacht.</span>
        </div>
        <div class="column1">
            <div class="box">
                <h3>Leader/Design</h3>
                <p>ㅈㅅㅎ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column2">
            <div class="box">
                <h3>Design</h3>
                <p>ㅅㅇㅅ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column3">
            <div class="box">
                <h3>Data Base</h3>
                <p>ㅊㅁㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
        <div class="column4">
            <div class="box">
                <h3>Main</h3>
                <p>ㅈㅇㄱ</p>
                <a href="#" class="button">문의/이메일</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>