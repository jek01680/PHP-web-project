﻿<!doctype html>
<!페이지 제목>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, minimum-scale=0.2, maximum-scale=0.3, user-scalable=yes" />
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
    <link href="default.css" rel="stylesheet" type="text/css" media="all" />
    <link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
    <script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
</head>
<body>
    <div id="wrapper">
        <div id="header-wrapper">
                <style>
                    #header {
                        width: 1000px;
                        margin: 0px auto;
                    }
                    #logo {
                        font-family: Calibri;
                        font-style: italic;
                        font-weight: lighter;
                        margin-top: 300px;
                        margin-left: 250px;
                        width: 500px;
                    }
                    #menu {
                        width: 1000px;
                        text-align: center;
                        background-color: #1b6ef2;
                    }
                </style>

            <div id="header" class="container">
                <div id="logo">
                    <h1><a href="#">'4' to 世明 </a></h1>
                    <p>by.computer science</p>
                </div>
            </div>
            <div id="menu" class="container">
                <ul>
                    <li class="current_page_item"><a href="intro.html"  accesskey="1" title="">home</a></li>
                    <li><a href="dorcount.html"  accesskey="2" title="">Dormitory</a></li>
                    <li><a href="lecevalu.html"  accesskey="3" title="">Lecture</a></li>
                    <li><a href="delivery.html" accesskey="4" title="">Delivery</a></li>
                    <li><a href="http://its.okjc.net/m01/map?category=1"  accesskey="5" title="">31'Bus</a></li>
                    <li><a href="signin.html"  accesskey="6" title="">sign in/sign up</a></li>
                </ul>
            </div>
        </div>
</body>

<!페이지 section>
    <style rel="stylesheet">
        body {
            background: -webkit-linear-gradient(45deg, rgba(66, 183, 245, 0.8) 0%, rgba(66, 245, 189, 0.4) 100%);
            background: linear-gradient(45deg, rgba(66, 183, 245, 0.8) 0%, rgba(66, 245, 189, 0.4) 100%);
        }
    </style>
    <style>
        #jb-container {
            width: 1160px;
            margin: 0px auto;
            padding: 20px;
            border: 1px solid #bcbcbc;
        }

        #jb-content {
            width: 860px;
            padding: 20px;
            margin-bottom: 20px;
            float: right;
            border: 1px solid #bcbcbc;
        }

        #jb-sidebar {
            width: 200px;
            padding: 20px;
            margin-bottom: 20px;
            float: left;
        }

        #jb-footer {
            clear: both;
            padding: 2px;
        }
    </style>

<body>
    <div id="jb-container">
        <div id="jb-content">
            <h2> 배달 모음집</h2>
            <!검색창>
            <style>
                form {
                    position: relative;
                    width: 800px;
                    margin: 15px auto;
                }
                .serch {
                    background: #2f9daa;
                }

                    .serch:after {
                        content: "";
                        clear: both;
                        display: table
                    }

                    .serch form {
                        width: auto;
                        float: right;
                        margin-right: 30px;
                    }

                    .serch input {
                        width: 170px;
                        height: 42px;
                        padding-left: 15px;
                        border-radius: 42px;
                        border: 2px solid #324b4e;
                        background: #F9F0DA;
                        outline: none;
                        position: relative;
                        transition: .3s linear;
                    }

                        .serch input:focus {
                            width: 250px;
                        }

                    .serch button {
                        width: 42px;
                        height: 42px;
                        background: none;
                        border: none;
                        position: absolute;
                        top: -2px;
                        right: 0;
                    }

                        .serch button:before {
                            content: "\f002";
                            font-family: FontAwesome;
                            color: #324b4e;
                        }
            </style>
            <div class="serch">
                <form name=" input" action="getid.jsp" method="get">
                    배달음식점 이름:
                    <input type="text" placeholder="배달 음식점 이름 입력">
                    <button type="submit" value="검색"></button>
                </form>
            </div>
            <!table생성>
            <style>            
                .lectable table {
                    width: 800px;
                    margin: 20px 0;
                    border: 0;
                }

                .lectable th {
                    font-weight: bold;
                    background-color: #c3b7c3;
                    color: #000;
                }

                .lectable, .lectable th, .lectable td {
                    font-size: 0.95em;
                    text-align: center;
                    padding: 4px;
                    border-collapse: collapse;
                }

                    .lectable th, .lectable td {
                        border: 1px solid #ffffff;
                        border-width: 1px 0 1px 0
                    }

                    .lectable tr {
                        border: 1px solid #ffffff;
                        margin: 0px;
                        padding: 0px;
                    }

                        .lectable tr:nth-child(odd) {
                            background-color: #f7f7f7;
                        }

                        .lectable tr:nth-child(even) {
                            background-color: #ffffff;
                        }

                .black_overlay {
                    display: none;
                    position: absolute;
                    top: 0%;
                    left: 0%;
                    width: 100%;
                    height: 100%;
                    background-color: black;
                    z-index: 1001;
                    opacity: .80;
                    filter: alpha(opacity=80);
                }

                .white_content {
                    display: none;
                    position: absolute;
                    top: 25%;
                    left: 25%;
                    width: 700px;
                    height: 800px;
                    padding: 16px;
                    border: 1px solid orange;
                    background-color: white;
                    z-index: 1002;
                    overflow: auto;
                }
               
            </style>  
            <table class="lectable">
                <tr>
                    <th width="30px;">번호</th>
                    <th width="180px;">음식점 이름</th>
                    <th width="180px;">전화번호</th>
                    <th width="40px;">위치</th>
                    <th width="240px;">메뉴 바로가기</th>
                    <th width="240px;">기타사항</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>일미리 금계찜닭</td>
                    <td>043-649-9995</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light1').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light1" class="white_content">
                            <img src="deliveryphoto/ilmiri.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light1').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                    <td>최소 주문금액:15,00원 이상</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>웅이네 오돌뼈</td>
                    <td>043-643-0101</td>
                    <td>정문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light2').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light2" class="white_content">
                            <img src="deliveryphoto/wongs.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light2').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>

                        <div id="fade" class="black_overlay"></div>
                    </td>
                    <td>최소 주문금액:15,00원 이상</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>바보스</td>
                    <td>043-644-4884</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light3').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light3" class="white_content">
                            <img src="deliveryphoto/babos.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light3').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>우리집 치킨 도시락</td>
                    <td>043-643-8977</td>
                    <td>?</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light4').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light4" class="white_content">
                            <img src="deliveryphoto/wori.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light4').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>와와 주먹밥&닭발</td>
                    <td>043-651-8883</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light5').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light5" class="white_content">
                            <img src="deliveryphoto/wawa.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light5').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>치킨더홈</td>
                    <td>043-648-9978</td>
                    <td>정문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light6').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light6" class="white_content">
                            <img src="deliveryphoto/thehome.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light6').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>스타곱스</td>
                    <td>043-647-9991</td>
                    <td>정문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light7').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light7" class="white_content">
                            <img src="deliveryphoto/star.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light7').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>밤새워</td>
                    <td>043-653-6685</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light8').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light8" class="white_content">
                            <img src="deliveryphoto/bamsae.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light8').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>뽕가곱창</td>
                    <td>043-652-5005</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light9').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light9" class="white_content">
                            <img src="deliveryphoto/bbong.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light9').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>청춘치킨</td>
                    <td>043-648-2010</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light10').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light10" class="white_content">
                            <img src="deliveryphoto/cheongchunchicken.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light10').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>11</td>
                    <td>청춘피자</td>
                    <td>043-647-1336</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light11').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light11" class="white_content">
                            <img src="deliveryphoto/cheongchunpizza.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light11').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>12</td>
                    <td>미처버린 치밥</td>
                    <td>043-652-9294</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light12').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light12" class="white_content">
                            <img src="deliveryphoto/chibab.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light12').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>13</td>
                    <td>꼬꼬숯불닭갈비</td>
                    <td>043-646-8372</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light13').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light13" class="white_content">
                            <img src="deliveryphoto/coco.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light13').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>14</td>
                    <td>퓨전탕수육</td>
                    <td>043-642-1366</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light14').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light14" class="white_content">
                            <img src="deliveryphoto/fusion.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light14').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>15</td>
                    <td>지코바</td>
                    <td>043-643-7589</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light15').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light15" class="white_content">
                            <img src="deliveryphoto/gcova.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light15').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>16</td>
                    <td>국물떡볶이</td>
                    <td>043-652-9294</td>
                    <td>?</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light16').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light16" class="white_content">
                            <img src="deliveryphoto/gugmul.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light16').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>17</td>
                    <td>호식이 두마리 치킨</td>
                    <td>043-651-3369</td>
                    <td>시내</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light17').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light17" class="white_content">
                            <img src="deliveryphoto/hosigi.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light17').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>18</td>
                    <td>대학로 인생밥집</td>
                    <td>043-644-7770</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light18').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light17" class="white_content">
                            <img src="deliveryphoto/insaeng.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light18').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>19</td>
                    <td>미투치킨</td>
                    <td>043-643-2288</td>
                    <td>정문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light19').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light19" class="white_content">
                            <img src="deliveryphoto/mito.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light19').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>20</td>
                    <td>맘스터치</td>
                    <td>043-644-8824</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light20').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light20" class="white_content">
                            <img src="deliveryphoto/moms.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light20').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>21</td>
                    <td>미쳐버린 파닭</td>
                    <td>043-652-9294</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light21').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light21" class="white_content">
                            <img src="deliveryphoto/padalg.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light21').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
                <tr>
                    <td>22</td>
                    <td>샌드리아</td>
                    <td>043-644-8685</td>
                    <td>후문</td>
                    <td>
                        <button href="javascript:void(0)" onclick="document.getElementById('light22').style.display='block';document.getElementById('fade').style.display='block'">메뉴판 바로가기</button>
                        <div id="light22" class="white_content">
                            <img src="deliveryphoto/sand.jpg" />
                            <button style="float:right;" href="javascript:void(0)" onclick="document.getElementById('light22').style.display='none';document.getElementById('fade').style.display='none'">x</button>
                        </div>
                        <div id="fade" class="black_overlay"></div>
                    </td>
                </tr>
            </table>
        </div>
        <!수직메뉴바생성>
        <style>
            body {
                margin: 20px auto;
                padding: 0;
                font-family: "맑은 고딕";
                font-size: 0.9em;
            }

            ul#navi {
                width: 200px;
                text-indent: 10px;
            }

                ul#navi, ul#navi ul {
                    margin: 0;
                    padding: 0;
                    list-style: none;
                }

            li.group {
                margin-bottom: 3px;
            }

                li.group div.title {
                    height: 35px;
                    line-height: 35px;
                    background: #f1e020;
                    cursor: pointer;
                }

            ul.sub li {
                margin-bottom: 2px;
                height: 35px;
                line-height: 35px;
                background: #f4f4f4;
                cursor: pointer;
            }

                ul.sub li a {
                    display: block;
                    width: 100%;
                    height: 100%;
                    text-decoration: none;
                    color: #000;
                }

                ul.sub li:hover {
                    background: #cf0;
                }
        </style>
        <div id="jb-sidebar">
            <ul id="navi">
                <li class="group">
                    <div class="title">배달음식</div>
                    <ul class="sub">
                        <li><a href="delivery.html">배달음식 모음</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        <div id="jb-footer">
            <P > </P>
        </div>
    </div>

    <div id="portfolio-wrapper">
        <div id="portfolio" class="container">
            <div class="title">
                <h2>세명대학교 컴퓨터학부 캡스톤 디자인 수업</h2>
                <span class="byline"></span>
            </div>
            <div class="column1">
                <div class="box">
                    <h3>Leader/Design</h3>
                    <p>ㅈㅅㅎ</p>
                    <a href="#" class="button">문의/이메일</a>
                </div>
            </div>
            <div class="column2">
                <div class="box">
                    <h3>.</h3>
                    <p>ㅅㅇㅅ</p>
                    <a href="#" class="button">문의/이메일</a>
                </div>
            </div>
            <div class="column3">
                <div class="box">
                    <h3>Data Base</h3>
                    <p>ㅊㅁㄱ</p>
                    <a href="#" class="button">문의/이메일</a>
                </div>
            </div>
            <div class="column4">
                <div class="box">
                    <h3>Main</h3>
                    <p>ㅈㅇㄱ</p>
                    <a href="#" class="button">문의/이메일</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>